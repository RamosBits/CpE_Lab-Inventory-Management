package cpe_lab_inventory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class DailyStockReportGenerator {
    public static boolean generateDailyStockReport(User user, String typeFilter) {
        String content = buildReportContent(user, typeFilter);
        showReportPreview(content, typeFilter);
        return true;
    }

    private static String buildReportContent(User user, String typeFilter) {
        ObservableList<Item> items = DatabaseManager.getAllItems();
        String dateTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        StringBuilder report = new StringBuilder();

        report.append("CPE LAB INVENTORY SYSTEM\n");
        report.append("DAILY STOCK REPORT\n");
        report.append("Scope       : ").append(typeFilter).append("\n");
        report.append("Date & Time : ").append(dateTime).append("\n");

        if (user != null) {
            report.append("Printed By  : ")
                  .append(user.getfName())
                  .append(" ")
                  .append(user.getlName())
                  .append(" (")
                  .append(user.getRoles())
                  .append(")\n");
        }

        report.append("\n");
        report.append(String.format(
            "%-8s %-28s %-12s %10s %13s %12s%n",
            "Item ID",
            "Item Name",
            "Type",
            "Total",
            "Current",
            "Borrowed"
        ));
        report.append(repeat("-", 90)).append("\n");

        int totalStock = 0;
        int currentStock = 0;
        int borrowedStock = 0;

        for (Item item : items) {
            if (!matchesTypeFilter(item, typeFilter)) {
                continue;
            }

            int borrowed = Math.max(item.getTotalStock() - item.getCurrentStock(), 0);
            totalStock += item.getTotalStock();
            currentStock += item.getCurrentStock();
            borrowedStock += borrowed;

            report.append(String.format(
                "%-8d %-28s %-12s %10d %13d %12d%n",
                item.getItemId(),
                truncate(item.getItemName(), 28),
                truncate(item.getType(), 12),
                item.getTotalStock(),
                item.getCurrentStock(),
                borrowed
            ));
        }

        report.append(repeat("-", 90)).append("\n");
        report.append(String.format(
            "%-50s %10d %13d %12d%n",
            "TOTAL",
            totalStock,
            currentStock,
            borrowedStock
        ));

        return report.toString();
    }

    private static boolean matchesTypeFilter(Item item, String typeFilter) {
        return "All Items".equalsIgnoreCase(typeFilter) ||
               item.getType().equalsIgnoreCase(typeFilter);
    }

    private static void showReportPreview(String content, String typeFilter) {
        TextArea textArea = new TextArea(content);
        textArea.setEditable(false);
        textArea.setWrapText(false);
        textArea.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 12;");

        BorderPane root = new BorderPane();
        root.setCenter(textArea);

        Button saveButton = new Button("Save Report");
        Button closeButton = new Button("Close");
        saveButton.setStyle("-fx-padding: 10 24;");
        closeButton.setStyle("-fx-padding: 10 24;");
        HBox buttons = new HBox(10, saveButton, closeButton);
        buttons.setStyle("-fx-padding: 10; -fx-alignment: CENTER_RIGHT;");
        root.setBottom(buttons);

        Stage stage = new Stage();
        stage.setTitle("Daily Stock Report Preview - " + typeFilter);
        stage.setScene(new Scene(root, 850, 650));

        saveButton.setOnAction(event -> saveReport(content, typeFilter, saveButton));
        closeButton.setOnAction(event -> stage.close());
        stage.showAndWait();
    }

    private static void saveReport(String content, String typeFilter, Button saveButton) {
        try {
            File reportsDir = AppPaths.getReportsDirectory();
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String scope = typeFilter.replace(" ", "_");
            File outputFile = new File(
                reportsDir,
                "Daily_Stock_Report_" + scope + "_" + timestamp + ".txt"
            );

            try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                fos.write(content.getBytes(StandardCharsets.UTF_8));
            }

            saveButton.setDisable(true);
            saveButton.setText("Saved");
            System.out.println("Daily stock report saved to: " + outputFile.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
            showErrorAlert("Error saving daily stock report: " + e.getMessage());
        }
    }

    private static void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Report Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private static String repeat(String text, int count) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < count; i++) {
            builder.append(text);
        }
        return builder.toString();
    }

    private static String truncate(String value, int length) {
        if (value == null) {
            return "";
        }
        if (value.length() <= length) {
            return value;
        }
        return value.substring(0, length - 3) + "...";
    }
}
