# CpE Lab Inventory Deployment

This project should use `MainApp.java` as the real app entry point:

```text
cpe_lab_inventory.MainApp
```

Do not rely on NetBeans `jfxsa-run` for deployment. That old Ant/JavaFX path can fail with Nashorn/ASM errors on modern JDKs.

## Local Linux Test Build

From the project root:

```bash
chmod +x deploy/build-linux.sh deploy/run-linux.sh
deploy/build-linux.sh
deploy/run-linux.sh
```

This creates:

```text
dist/manual/CpE_Lab_Inventory.jar
dist/manual/lib/mysql-connector-j-8.0.33.jar
```

## Database Export On Linux

Make sure MySQL is running, then:

```bash
chmod +x deploy/export-database-linux.sh
deploy/export-database-linux.sh
```

This creates:

```text
database-backup/cpelab_db.sql
```

Copy this whole project folder to the Windows 10 deployment PC.

## Windows Requirements

Install these on Windows 10:

- JDK 25 with `javac`, `jar`, and `jpackage`
- JavaFX SDK 25
- MySQL Server
- MySQL Connector/J 8.0.33

Suggested Windows paths:

```text
C:\JavaFX\javafx-sdk-25.0.2\lib
C:\CpE_Lab_Inventory\lib\mysql-connector-j-8.0.33.jar
```

If your paths are different, edit these files:

```text
deploy\windows\build-windows.bat
deploy\windows\run-windows.bat
deploy\windows\package-windows.bat
```

## Import Database On Windows

Put the SQL file here:

```text
database-backup\cpelab_db.sql
```

Then run:

```bat
deploy\windows\import-database-windows.bat
```

The app currently expects:

```text
Database: cpelab_db
User: root
Password: root
URL: jdbc:mysql://localhost:3306/cpelab_db
```

## Where Receipts And Reports Are Saved

The packaged app does not save generated files inside the install folder.
It saves them in the current Windows user's Documents folder:

```text
C:\Users\<WindowsUser>\Documents\CpE Lab Inventory\Receipts
C:\Users\<WindowsUser>\Documents\CpE Lab Inventory\Reports
```

On Linux, the equivalent is:

```text
/home/<user>/Documents/CpE Lab Inventory/Receipts
/home/<user>/Documents/CpE Lab Inventory/Reports
```

This keeps printed/generated files writable even if the app is installed in a protected folder.

## Build And Run On Windows

From the project root:

```bat
deploy\windows\build-windows.bat
deploy\windows\run-windows.bat
```

## Create A Windows App Folder

After the build works:

```bat
deploy\windows\package-windows.bat
```

This creates an app image in:

```text
dist\installer
```

That is the folder you can copy/run as the deployed app.
