package cpe_lab_inventory;

public class ItemUnit {
    private int unitId;
    private int itemId;
    private String unitCode;
    private String status;
    private String borrowedOrNumber;

    public ItemUnit(
            int unitId,
            int itemId,
            String unitCode,
            String status,
            String borrowedOrNumber) {

        this.unitId = unitId;
        this.itemId = itemId;
        this.unitCode = unitCode;
        this.status = status;
        this.borrowedOrNumber = borrowedOrNumber;
    }

    public int getUnitId() { return unitId; }
    public int getItemId() { return itemId; }
    public String getUnitCode() { return unitCode; }
    public String getStatus() { return status; }
    public String getBorrowedOrNumber() { return borrowedOrNumber; }

    @Override
    public String toString() {
        return unitCode;
    }
}
