package cpe_lab_inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseManager {
    private static final String URL = "jdbc:mysql://localhost:3306/cpelab_db";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static User authenticateUser(String username, String password) {
        try (Connection conn = getConnection()) {
            String query = "SELECT user_id, username, password, f_name, l_name, roles FROM users WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String storedPassword = rs.getString("password");
                if (storedPassword.equals(password)) {
                    return new User(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("f_name"),
                        rs.getString("l_name"),
                        rs.getString("roles")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean addItem(String itemName, String type, int totalStock, int userId) {
        try (Connection conn = getConnection()) {
            String query = "INSERT INTO items (item_name, type, total_stock, current_stock, users_user_id, timestamp) VALUES (?, ?, ?, ?, ?, NOW())";
            PreparedStatement stmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
            stmt.setString(1, itemName);
            stmt.setString(2, type);
            stmt.setInt(3, totalStock);
            stmt.setInt(4, totalStock);
            stmt.setInt(5, userId);
            stmt.executeUpdate();

            ResultSet generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next() && isUnitTrackedType(type)) {
                createItemUnits(generatedKeys.getInt(1), totalStock, "Available");
            }

            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean saveStudent(String studentId, String name, String course, int yearLevel, String contactNumber) {
        try (Connection conn = getConnection()) {
            String query = "INSERT INTO students (student_id, name, course, year_level, contact_number) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, studentId);
            stmt.setString(2, name);
            stmt.setString(3, course);
            stmt.setInt(4, yearLevel);
            stmt.setString(5, contactNumber);
            
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static ObservableList<String> getStudentsList() {
        ObservableList<String> studentList = FXCollections.observableArrayList();
        try (Connection conn = getConnection()) {
            String query = "SELECT CONCAT(student_id, ' - ', name) as display FROM students WHERE is_deleted = 0 ORDER BY name";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                studentList.add(rs.getString("display"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return studentList;
    }

    public static boolean updateItem(int itemId, String itemName, String type, int totalStock) {
        try (Connection conn = getConnection()) {
            String query = "UPDATE items SET item_name = ?, type = ?, total_stock = ? WHERE item_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, itemName);
            stmt.setString(2, type);
            stmt.setInt(3, totalStock);
            stmt.setInt(4, itemId);
            
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean updateItem(int itemId, String itemName, String type, int totalStock, int currentStock) {
        try (Connection conn = getConnection()) {
            String query = "UPDATE items SET item_name = ?, type = ?, total_stock = ?, current_stock = ? WHERE item_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, itemName);
            stmt.setString(2, type);
            stmt.setInt(3, totalStock);
            stmt.setInt(4, currentStock);
            stmt.setInt(5, itemId);
            
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean deleteItem(int itemId) {
        try (Connection conn = getConnection()) {
            String query = "UPDATE items SET is_deleted = 1 WHERE item_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, itemId);
            
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static ObservableList<Item> getAllItems() {
        ObservableList<Item> itemList = FXCollections.observableArrayList();
        try (Connection conn = getConnection()) {
            String query = "SELECT item_id, item_name, type, total_stock, current_stock, users_user_id, timestamp FROM items WHERE is_deleted = 0 ORDER BY item_id";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Item item = new Item(
                    rs.getInt("item_id"),
                    rs.getString("item_name"),
                    rs.getString("type"),
                    rs.getInt("total_stock"),
                    rs.getInt("current_stock"),
                    rs.getInt("users_user_id"),
                    rs.getString("timestamp")
                );
                itemList.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return itemList;
    }

    public static ObservableList<Student> getAllStudents() {
        ObservableList<Student> studentList = FXCollections.observableArrayList();
        try (Connection conn = getConnection()) {
            String query = "SELECT student_id, name, course, year_level, contact_number, registered_at FROM students WHERE is_deleted = 0 ORDER BY name";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Student student = new Student(
                    rs.getString("student_id"),
                    rs.getString("name"),
                    rs.getString("course"),
                    rs.getInt("year_level"),
                    rs.getString("contact_number"),
                    rs.getString("registered_at")
                );
                studentList.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return studentList;
    }

    public static boolean deleteStudent(String studentId) {
        try (Connection conn = getConnection()) {
            String query = "UPDATE students SET is_deleted = 1 WHERE student_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, studentId);
            
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static ObservableList<Transaction> getAllTransactions() {
        ObservableList<Transaction> transactionList = FXCollections.observableArrayList();
        try (Connection conn = getConnection()) {
            String query = "SELECT t.transaction_id, t.student_id, s.name as student_name, t.item_id, i.item_name, t.quantity_taken, t.quantity_returned, t.or_num, t.status, t.borrow_date, t.return_date FROM transactions t LEFT JOIN students s ON t.student_id = s.student_id LEFT JOIN items i ON t.item_id = i.item_id WHERE t.is_deleted = 0 ORDER BY t.or_num DESC, t.transaction_id DESC";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                int quantityReturned = rs.getInt("quantity_returned");
                String returnDateStr = rs.getString("return_date");
                Transaction transaction = new Transaction(
                    rs.getInt("transaction_id"),
                    rs.getString("student_id"),
                    rs.getString("student_name"),
                    rs.getInt("item_id"),
                    rs.getString("item_name"),
                    rs.getInt("quantity_taken"),
                    quantityReturned,
                    rs.getInt("or_num"),
                    rs.getString("status"),
                    rs.getString("borrow_date"),
                    returnDateStr
                );
                transactionList.add(transaction);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return transactionList;
    }

    public static boolean addTransaction(String studentId, int encoderId, String itemIdStr, int quantity, int orNum, String status) {
        try (Connection conn = getConnection()) {
            int itemId = Integer.parseInt(itemIdStr.trim());
            String cleanStudentId = studentId.trim();
            
            // Convert status to past tense: "Borrow" -> "Borrowed", "Return" -> "Returned"
            String statusValue = status.equalsIgnoreCase("Borrow") ? "Borrowed" : (status.equalsIgnoreCase("Return") ? "Returned" : status);
            
            System.out.println("DEBUG - Adding Transaction: studentId=" + cleanStudentId + ", encoderId=" + encoderId + ", itemId=" + itemId + ", quantity=" + quantity + ", orNum=" + orNum + ", status=" + statusValue);
            
            // Start transaction
            conn.setAutoCommit(false);
            
            try {
                // Insert transaction record
                String query = "INSERT INTO transactions (student_id, encoder_id, item_id, quantity_taken, or_num, borrow_date, status, timestamp) VALUES (?, ?, ?, ?, ?, NOW(), ?, NOW())";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, cleanStudentId);
                stmt.setInt(2, encoderId);
                stmt.setInt(3, itemId);
                stmt.setInt(4, quantity);
                stmt.setInt(5, orNum);
                stmt.setString(6, statusValue);
                
                int rowsInserted = stmt.executeUpdate();
                
                if (rowsInserted > 0) {
                    // Update current stock based on transaction type
                    if (statusValue.equalsIgnoreCase("Borrowed")) {
                        // Decrease stock on borrow
                        updateCurrentStock(conn, itemId, -quantity);
                    } else if (statusValue.equalsIgnoreCase("Returned")) {
                        // Increase stock on return
                        updateCurrentStock(conn, itemId, quantity);
                    }
                    
                    conn.commit();
                    return true;
                } else {
                    conn.rollback();
                }
            } catch (SQLException e) {
                conn.rollback();
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            System.out.println("SQL Error in addTransaction: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    private static void updateCurrentStock(Connection conn, int itemId, int quantityChange) throws SQLException {
        String query = "UPDATE items SET current_stock = current_stock + ? WHERE item_id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, quantityChange);
        stmt.setInt(2, itemId);
        stmt.executeUpdate();
        
        System.out.println("DEBUG - Updated stock for itemId=" + itemId + " by " + quantityChange);
    }

    public static int getNextOrNumber() {
        try (Connection conn = getConnection()) {
            String query = "SELECT MAX(or_num) as max_or FROM transactions";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                int maxOr = rs.getInt("max_or");
                return maxOr + 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1; // Return 1 if no transactions exist yet
    }

    public static boolean returnItem(int transactionId, int quantityReturning) {
        try (Connection conn = getConnection()) {
            // Fetch current transaction details
            String fetchQuery = "SELECT item_id, quantity_taken FROM transactions WHERE transaction_id = ?";
            PreparedStatement fetchStmt = conn.prepareStatement(fetchQuery);
            fetchStmt.setInt(1, transactionId);
            ResultSet rs = fetchStmt.executeQuery();
            
            if (!rs.next()) {
                System.out.println("ERROR - Transaction not found: transactionId=" + transactionId);
                return false;
            }
            
            int itemId = rs.getInt("item_id");
            int quantityTaken = rs.getInt("quantity_taken");
            
            // Determine new status based on return quantity
            String newStatus = (quantityReturning < quantityTaken) ? "Partially Returned" : "Returned";
            
            System.out.println("DEBUG - Processing return: transactionId=" + transactionId + 
                             ", itemId=" + itemId + ", quantityTaken=" + quantityTaken + 
                             ", quantityReturning=" + quantityReturning + ", newStatus=" + newStatus);
            
            // Start database transaction
            conn.setAutoCommit(false);
            
            try {
                int newQuantityTaken = quantityTaken - quantityReturning;
                if (newQuantityTaken < 0) newQuantityTaken = 0;
                // Update transaction with quantity_returned, quantity_taken, and status
                String updateQuery = "UPDATE transactions SET quantity_returned = ?, quantity_taken = ?, status = ?, return_date = NOW() WHERE transaction_id = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
                updateStmt.setInt(1, quantityReturning);
                updateStmt.setInt(2, newQuantityTaken);
                updateStmt.setString(3, newStatus);
                updateStmt.setInt(4, transactionId);
                
                int rowsUpdated = updateStmt.executeUpdate();
                
                if (rowsUpdated > 0) {
                    // Increment current stock by returned quantity
                    updateCurrentStock(conn, itemId, quantityReturning);
                    
                    conn.commit();
                    System.out.println("DEBUG - Return processed successfully: transactionId=" + transactionId);
                    return true;
                } else {
                    conn.rollback();
                    System.out.println("ERROR - Failed to update transaction: transactionId=" + transactionId);
                }
            } catch (SQLException e) {
                conn.rollback();
                System.out.println("ERROR - Exception during return: " + e.getMessage());
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            System.out.println("SQL Error in returnItem: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    public static boolean deleteTransaction(int transactionId) {
        try (Connection conn = getConnection()) {
            // Fetch transaction details to restore inventory
            String fetchQuery = "SELECT item_id, quantity_taken FROM transactions WHERE transaction_id = ?";
            PreparedStatement fetchStmt = conn.prepareStatement(fetchQuery);
            fetchStmt.setInt(1, transactionId);
            ResultSet rs = fetchStmt.executeQuery();
            
            if (!rs.next()) {
                System.out.println("ERROR - Transaction not found: transactionId=" + transactionId);
                return false;
            }
            
            int itemId = rs.getInt("item_id");
            int quantityTaken = rs.getInt("quantity_taken");
            
            System.out.println("DEBUG - Deleting transaction: transactionId=" + transactionId + 
                             ", itemId=" + itemId + ", quantityTaken=" + quantityTaken);
            
            // Start database transaction
            conn.setAutoCommit(false);
            
            try {
                // Restore inventory by adding back the quantity
                updateCurrentStock(conn, itemId, quantityTaken);
                
                // Soft delete the transaction
                String deleteQuery = "UPDATE transactions SET is_deleted = 1 WHERE transaction_id = ?";
                PreparedStatement deleteStmt = conn.prepareStatement(deleteQuery);
                deleteStmt.setInt(1, transactionId);
                
                int rowsUpdated = deleteStmt.executeUpdate();
                
                if (rowsUpdated > 0) {
                    conn.commit();
                    System.out.println("DEBUG - Transaction soft deleted and inventory restored: transactionId=" + transactionId);
                    return true;
                } else {
                    conn.rollback();
                    System.out.println("ERROR - Failed to delete transaction: transactionId=" + transactionId);
                }
            } catch (SQLException e) {
                conn.rollback();
                System.out.println("ERROR - Exception during delete: " + e.getMessage());
                throw e;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            System.out.println("SQL Error in deleteTransaction: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    // ========== Item Unit Code Methods ==========

    public static boolean isUnitTrackedType(String type) {
        return "Tool".equalsIgnoreCase(type) || "Equipment".equalsIgnoreCase(type);
    }

    private static void ensureItemUnitsTable(Connection conn) throws SQLException {
        String query = "CREATE TABLE IF NOT EXISTS item_units (" +
                       "unit_id INT PRIMARY KEY AUTO_INCREMENT, " +
                       "item_id INT NOT NULL, " +
                       "unit_code VARCHAR(50) UNIQUE NOT NULL, " +
                       "status VARCHAR(30) DEFAULT 'Available', " +
                       "borrowed_or_num INT NULL, " +
                       "is_deleted TINYINT DEFAULT 0, " +
                       "created_at DATETIME DEFAULT CURRENT_TIMESTAMP)";
        conn.prepareStatement(query).executeUpdate();
        addColumnIfMissing(conn, "status", "VARCHAR(30) DEFAULT 'Available'");
        addColumnIfMissing(conn, "borrowed_or_num", "INT NULL");
        addColumnIfMissing(conn, "is_deleted", "TINYINT DEFAULT 0");
        addColumnIfMissing(conn, "created_at", "DATETIME DEFAULT CURRENT_TIMESTAMP");
    }

    private static void addColumnIfMissing(
            Connection conn,
            String columnName,
            String columnDefinition) throws SQLException {

        String checkQuery = "SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS " +
                            "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'item_units' " +
                            "AND COLUMN_NAME = ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
        checkStmt.setString(1, columnName);
        ResultSet rs = checkStmt.executeQuery();

        if (rs.next() && rs.getInt("count") == 0) {
            String alterQuery = "ALTER TABLE item_units ADD COLUMN " +
                                columnName + " " + columnDefinition;
            conn.prepareStatement(alterQuery).executeUpdate();
        }
    }

    public static ObservableList<ItemUnit> getItemUnits(int itemId) {
        ObservableList<ItemUnit> units = FXCollections.observableArrayList();

        try (Connection conn = getConnection()) {
            ensureItemUnitsTable(conn);

            String query = "SELECT unit_id, item_id, unit_code, status, borrowed_or_num " +
                           "FROM item_units WHERE item_id = ? AND is_deleted = 0 " +
                           "ORDER BY unit_code";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, itemId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                units.add(new ItemUnit(
                    rs.getInt("unit_id"),
                    rs.getInt("item_id"),
                    rs.getString("unit_code"),
                    rs.getString("status"),
                    formatOrNumber(rs.getObject("borrowed_or_num"))
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return units;
    }

    public static boolean ensureItemUnits(Item item) {
        if (!isUnitTrackedType(item.getType())) {
            return true;
        }

        try (Connection conn = getConnection()) {
            ensureItemUnitsTable(conn);
            reconcileItemUnits(conn, item);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static String formatOrNumber(Object orNumber) {
        return orNumber == null ? "-" : String.valueOf(orNumber);
    }

    private static void reconcileItemUnits(Connection conn, Item item) throws SQLException {
        int currentUnitCount = countItemUnits(conn, item.getItemId());
        int stockDifference = item.getTotalStock() - currentUnitCount;

        if (stockDifference > 0) {
            int nextSeq = getNextUnitSequence(conn, item.getItemId());
            insertItemUnits(conn, item.getItemId(), stockDifference, nextSeq, "Available");
        } else if (stockDifference < 0) {
            softDeleteExtraUnits(conn, item.getItemId(), Math.abs(stockDifference));
        }

        resetUnitsAvailable(conn, item.getItemId());
        assignBorrowedUnits(conn, item.getItemId(), item.getCurrentStock());
    }

    private static int countItemUnits(Connection conn, int itemId) throws SQLException {
        String query = "SELECT COUNT(*) as count FROM item_units " +
                       "WHERE item_id = ? AND is_deleted = 0";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, itemId);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            return rs.getInt("count");
        }

        return 0;
    }

    private static int getNextUnitSequence(Connection conn, int itemId) throws SQLException {
        String query = "SELECT MAX(CAST(SUBSTRING(unit_code, " +
                       "LOCATE('-', unit_code) + 1) AS UNSIGNED)) " +
                       "as max_seq FROM item_units WHERE item_id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, itemId);
        ResultSet rs = stmt.executeQuery();

        if (rs.next() && rs.getInt("max_seq") > 0) {
            return rs.getInt("max_seq") + 1;
        }

        return 1;
    }

    private static void softDeleteExtraUnits(
            Connection conn,
            int itemId,
            int deleteCount) throws SQLException {

        String query = "UPDATE item_units SET is_deleted = 1 " +
                       "WHERE item_id = ? AND is_deleted = 0 " +
                       "ORDER BY unit_code DESC LIMIT ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, itemId);
        stmt.setInt(2, deleteCount);
        stmt.executeUpdate();
    }

    private static void resetUnitsAvailable(Connection conn, int itemId) throws SQLException {
        String query = "UPDATE item_units SET status = 'Available', borrowed_or_num = NULL " +
                       "WHERE item_id = ? AND is_deleted = 0";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, itemId);
        stmt.executeUpdate();
    }

    private static void assignBorrowedUnits(
            Connection conn,
            int itemId,
            int currentStock) throws SQLException {

        int totalUnits = countItemUnits(conn, itemId);
        int borrowedCount = Math.max(totalUnits - currentStock, 0);

        if (borrowedCount <= 0) {
            return;
        }

        ObservableList<Integer> orNumbers = getActiveBorrowedOrNumbers(conn, itemId);
        String query = "SELECT unit_id FROM item_units " +
                       "WHERE item_id = ? AND is_deleted = 0 " +
                       "ORDER BY unit_code LIMIT ? OFFSET ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, itemId);
        stmt.setInt(2, borrowedCount);
        stmt.setInt(3, Math.max(currentStock, 0));
        ResultSet rs = stmt.executeQuery();

        int index = 0;
        while (rs.next()) {
            Integer orNumber = index < orNumbers.size() ? orNumbers.get(index) : null;
            updateUnitBorrowState(conn, rs.getInt("unit_id"), orNumber);
            index++;
        }
    }

    private static ObservableList<Integer> getActiveBorrowedOrNumbers(
            Connection conn,
            int itemId) throws SQLException {

        ObservableList<Integer> orNumbers = FXCollections.observableArrayList();
        String query = "SELECT or_num, quantity_taken FROM transactions " +
                       "WHERE item_id = ? AND is_deleted = 0 " +
                       "AND status IN ('Borrowed', 'Partially Returned') " +
                       "AND quantity_taken > 0 ORDER BY borrow_date, transaction_id";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setInt(1, itemId);
        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            int quantity = rs.getInt("quantity_taken");
            for (int i = 0; i < quantity; i++) {
                orNumbers.add(rs.getInt("or_num"));
            }
        }

        return orNumbers;
    }

    private static void updateUnitBorrowState(
            Connection conn,
            int unitId,
            Integer orNumber) throws SQLException {

        String query = "UPDATE item_units SET status = 'Borrowed', borrowed_or_num = ? " +
                       "WHERE unit_id = ?";
        PreparedStatement stmt = conn.prepareStatement(query);

        if (orNumber == null) {
            stmt.setNull(1, java.sql.Types.INTEGER);
        } else {
            stmt.setInt(1, orNumber);
        }

        stmt.setInt(2, unitId);
        stmt.executeUpdate();
    }

    private static void insertItemUnits(
            Connection conn,
            int itemId,
            int quantity,
            int nextSeq,
            String status) throws SQLException {

        String query = "INSERT INTO item_units (item_id, unit_code, status) " +
                       "VALUES (?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(query);

        for (int i = 0; i < quantity; i++) {
            stmt.setInt(1, itemId);
            stmt.setString(2, String.format("%d-%03d", itemId, nextSeq + i));
            stmt.setString(3, status);
            stmt.addBatch();
        }

        stmt.executeBatch();
    }

    private static boolean createItemUnits(int itemId, int quantity, String status) {
        if (quantity <= 0) {
            return true;
        }

        try (Connection conn = getConnection()) {
            ensureItemUnitsTable(conn);
            int nextSeq = getNextUnitSequence(conn, itemId);
            insertItemUnits(conn, itemId, quantity, nextSeq, status);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private static void markUnavailableUnits(int itemId, int availableCount) {
        ObservableList<ItemUnit> units = getItemUnits(itemId);

        for (int i = availableCount; i < units.size(); i++) {
            updateItemUnitStatus(units.get(i).getUnitId(), "Borrowed");
        }
    }

    public static boolean updateItemUnitStatus(int unitId, String status) {
        try (Connection conn = getConnection()) {
            ensureItemUnitsTable(conn);

            String query = "UPDATE item_units SET status = ? WHERE unit_id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, status);
            stmt.setInt(2, unitId);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ========== Calibration / Condition History Methods ==========

    private static void ensureCalibrationHistoryTable(Connection conn) throws SQLException {
        String query = "CREATE TABLE IF NOT EXISTS calibration_history (" +
                       "calibration_id INT PRIMARY KEY AUTO_INCREMENT, " +
                       "item_id INT NOT NULL, " +
                       "unit_id INT NULL, " +
                       "status VARCHAR(40) NOT NULL, " +
                       "notes TEXT, " +
                       "checked_by INT, " +
                       "checked_at DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                       "is_deleted TINYINT DEFAULT 0)";
        conn.prepareStatement(query).executeUpdate();
        addCalibrationColumnIfMissing(conn, "unit_id", "INT NULL");
    }

    private static void addCalibrationColumnIfMissing(
            Connection conn,
            String columnName,
            String columnDefinition) throws SQLException {

        String checkQuery = "SELECT COUNT(*) as count FROM INFORMATION_SCHEMA.COLUMNS " +
                            "WHERE TABLE_SCHEMA = DATABASE() " +
                            "AND TABLE_NAME = 'calibration_history' " +
                            "AND COLUMN_NAME = ?";
        PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
        checkStmt.setString(1, columnName);
        ResultSet rs = checkStmt.executeQuery();

        if (rs.next() && rs.getInt("count") == 0) {
            String alterQuery = "ALTER TABLE calibration_history ADD COLUMN " +
                                columnName + " " + columnDefinition;
            conn.prepareStatement(alterQuery).executeUpdate();
        }
    }

    public static boolean addCalibrationRecord(
            int itemId,
            int unitId,
            String status,
            String notes,
            int checkedBy) {

        try (Connection conn = getConnection()) {
            ensureCalibrationHistoryTable(conn);

            String query = "INSERT INTO calibration_history " +
                           "(item_id, unit_id, status, notes, checked_by, checked_at) " +
                           "VALUES (?, ?, ?, ?, ?, NOW())";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, itemId);
            stmt.setInt(2, unitId);
            stmt.setString(3, status);
            stmt.setString(4, notes);
            stmt.setInt(5, checkedBy);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static ObservableList<CalibrationRecord> getCalibrationHistory(
            int itemId,
            int unitId) {

        ObservableList<CalibrationRecord> records = FXCollections.observableArrayList();

        try (Connection conn = getConnection()) {
            ensureCalibrationHistoryTable(conn);

            String query = "SELECT c.calibration_id, c.item_id, c.unit_id, iu.unit_code, " +
                           "c.status, c.notes, " +
                           "c.checked_at, CONCAT(u.f_name, ' ', u.l_name) as checked_by " +
                           "FROM calibration_history c " +
                           "LEFT JOIN users u ON c.checked_by = u.user_id " +
                           "LEFT JOIN item_units iu ON c.unit_id = iu.unit_id " +
                           "WHERE c.item_id = ? AND c.unit_id = ? AND c.is_deleted = 0 " +
                           "ORDER BY c.checked_at DESC, c.calibration_id DESC";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, itemId);
            stmt.setInt(2, unitId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                records.add(new CalibrationRecord(
                    rs.getInt("calibration_id"),
                    rs.getInt("item_id"),
                    rs.getInt("unit_id"),
                    rs.getString("unit_code"),
                    rs.getString("status"),
                    rs.getString("notes"),
                    rs.getString("checked_at"),
                    rs.getString("checked_by")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return records;
    }
}
