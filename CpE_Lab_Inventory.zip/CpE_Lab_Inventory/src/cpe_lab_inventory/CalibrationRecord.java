package cpe_lab_inventory;

public class CalibrationRecord {
    private int calibrationId;
    private int itemId;
    private int unitId;
    private String unitCode;
    private String status;
    private String notes;
    private String checkedAt;
    private String checkedBy;

    public CalibrationRecord(
            int calibrationId,
            int itemId,
            int unitId,
            String unitCode,
            String status,
            String notes,
            String checkedAt,
            String checkedBy) {

        this.calibrationId = calibrationId;
        this.itemId = itemId;
        this.unitId = unitId;
        this.unitCode = unitCode;
        this.status = status;
        this.notes = notes;
        this.checkedAt = checkedAt;
        this.checkedBy = checkedBy;
    }

    public int getCalibrationId() { return calibrationId; }
    public int getItemId() { return itemId; }
    public int getUnitId() { return unitId; }
    public String getUnitCode() { return unitCode; }
    public String getStatus() { return status; }
    public String getNotes() { return notes; }
    public String getCheckedAt() { return checkedAt; }
    public String getCheckedBy() { return checkedBy; }
}
