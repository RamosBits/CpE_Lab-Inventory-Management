package cpe_lab_inventory;

import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

public class ItemUnitsDialogController {
    private static class UnitLoadResult {
        private final boolean unitsReady;
        private final ObservableList<ItemUnit> units;

        UnitLoadResult(boolean unitsReady, ObservableList<ItemUnit> units) {
            this.unitsReady = unitsReady;
            this.units = units;
        }
    }

    @FXML
    private Label itemLabel;
    @FXML
    private Label countLabel;
    @FXML
    private TableView<ItemUnit> unitsTable;
    @FXML
    private TableColumn<ItemUnit, String> unitCodeColumn;
    @FXML
    private TableColumn<ItemUnit, String> statusColumn;
    @FXML
    private TableColumn<ItemUnit, String> orNumberColumn;

    private Stage dialogStage;

    @FXML
    public void initialize() {
        unitCodeColumn.setCellValueFactory(new PropertyValueFactory<>("unitCode"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        orNumberColumn.setCellValueFactory(new PropertyValueFactory<>("borrowedOrNumber"));
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public void setItem(Item item) {
        itemLabel.setText(item.getItemName() + " (Item ID: " + item.getItemId() + ")");
        countLabel.setText("Loading unit codes...");
        unitsTable.getItems().clear();

        Task<UnitLoadResult> loadTask = new Task<UnitLoadResult>() {
            @Override
            protected UnitLoadResult call() {
                boolean unitsReady = DatabaseManager.ensureItemUnits(item);
                ObservableList<ItemUnit> units = DatabaseManager.getItemUnits(item.getItemId());
                return new UnitLoadResult(unitsReady, units);
            }
        };

        loadTask.setOnSucceeded(event -> {
            UnitLoadResult result = loadTask.getValue();
            countLabel.setText("Total Units: " + result.units.size());
            unitsTable.setItems(result.units);

            if (!result.unitsReady) {
                showUnitLoadError();
            }
        });

        loadTask.setOnFailed(event -> {
            countLabel.setText("Total Units: 0");
            loadTask.getException().printStackTrace();
            showUnitLoadError();
        });

        Thread loadThread = new Thread(loadTask);
        loadThread.setDaemon(true);
        loadThread.start();
    }

    private void showUnitLoadError() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Unit Codes Not Created");
        alert.setHeaderText(null);
        alert.setContentText("The unit codes could not be created. Check the Output window.");
        alert.showAndWait();
    }

    @FXML
    private void handleClose() {
        dialogStage.close();
    }

    public static void show(Window owner, Item item) {
        if (!DatabaseManager.isUnitTrackedType(item.getType())) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Quantity Only");
            alert.setHeaderText(null);
            alert.setContentText("Consumable items are tracked by quantity only.");
            alert.showAndWait();
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(
                ItemUnitsDialogController.class.getResource("ItemUnitsDialog.fxml")
            );
            Stage stage = new Stage();
            stage.setTitle("Item Units");
            stage.initOwner(owner);
            stage.initModality(Modality.WINDOW_MODAL);
            stage.setScene(new Scene(loader.load()));

            ItemUnitsDialogController controller = loader.getController();
            controller.setDialogStage(stage);
            controller.setItem(item);

            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
