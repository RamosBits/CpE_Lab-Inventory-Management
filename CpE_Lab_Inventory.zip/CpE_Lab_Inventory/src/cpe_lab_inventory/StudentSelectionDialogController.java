package cpe_lab_inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class StudentSelectionDialogController {
    @FXML
    private TableView<Student> studentsTable;
    @FXML
    private TextField searchField;
    @FXML
    private TableColumn<Student, String> studentIdColumn;
    @FXML
    private TableColumn<Student, String> nameColumn;
    @FXML
    private TableColumn<Student, String> courseColumn;
    @FXML
    private TableColumn<Student, Integer> yearColumn;
    @FXML
    private TableColumn<Student, String> contactColumn;

    private ObservableList<Student> allStudents;
    private Student selectedStudent;
    private Stage dialogStage;

    @FXML
    public void initialize() {
        setupTableColumns();
        loadStudents();
    }

    private void setupTableColumns() {
        studentIdColumn.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        courseColumn.setCellValueFactory(new PropertyValueFactory<>("course"));
        yearColumn.setCellValueFactory(new PropertyValueFactory<>("yearLevel"));
        contactColumn.setCellValueFactory(new PropertyValueFactory<>("contactNumber"));
    }

    @FXML
    private void handleSearch() {
        String searchText = searchField.getText().toLowerCase();
        
        if (searchText.isEmpty()) {
            studentsTable.setItems(allStudents);
            return;
        }

        ObservableList<Student> filteredStudents = FXCollections.observableArrayList();
        for (Student student : allStudents) {
            if (student.getStudentId().toLowerCase().contains(searchText) ||
                student.getName().toLowerCase().contains(searchText) ||
                student.getCourse().toLowerCase().contains(searchText)) {
                filteredStudents.add(student);
            }
        }
        studentsTable.setItems(filteredStudents);
    }

    @FXML
    private void handleSelect() {
        selectedStudent = studentsTable.getSelectionModel().getSelectedItem();
        if (selectedStudent == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Selection");
            alert.setHeaderText(null);
            alert.setContentText("Please select a student.");
            alert.showAndWait();
            return;
        }
        dialogStage.close();
    }

    @FXML
    private void handleCancel() {
        selectedStudent = null;
        dialogStage.close();
    }

    private void loadStudents() {
        try {
            allStudents = DatabaseManager.getAllStudents();
            studentsTable.setItems(allStudents);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public Student getSelectedStudent() {
        return selectedStudent;
    }

    public static Student showStudentSelectionDialog() {
        try {
            FXMLLoader loader = new FXMLLoader(StudentSelectionDialogController.class.getResource("StudentSelectionDialog.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Select Student");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(true);

            StudentSelectionDialogController controller = loader.getController();
            controller.setDialogStage(stage);

            stage.showAndWait();
            return controller.getSelectedStudent();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
