package cpe_lab_inventory;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleStringProperty;

public class BulkReturnItem {
    private final int transactionId;
    private final int itemId;
    private final StringProperty itemName;
    private final IntegerProperty quantityBorrowed;
    private final IntegerProperty quantityReturned;
    private final IntegerProperty outstanding;
    private final IntegerProperty returnQuantity;

    public BulkReturnItem(int transactionId, int itemId, String itemName, 
                         int quantityBorrowed, int quantityReturned, int outstanding) {
        this.transactionId = transactionId;
        this.itemId = itemId;
        this.itemName = new SimpleStringProperty(itemName);
        this.quantityBorrowed = new SimpleIntegerProperty(quantityBorrowed);
        this.quantityReturned = new SimpleIntegerProperty(quantityReturned);
        this.outstanding = new SimpleIntegerProperty(outstanding);
        this.returnQuantity = new SimpleIntegerProperty(0);
    }

    public int getTransactionId() { return transactionId; }
    public int getItemId() { return itemId; }
    
    public String getItemName() { return itemName.get(); }
    public StringProperty itemNameProperty() { return itemName; }
    
    public int getQuantityBorrowed() { return quantityBorrowed.get(); }
    public IntegerProperty quantityBorrowedProperty() { return quantityBorrowed; }
    
    public int getQuantityReturned() { return quantityReturned.get(); }
    public IntegerProperty quantityReturnedProperty() { return quantityReturned; }
    
    public int getOutstanding() { return outstanding.get(); }
    public IntegerProperty outstandingProperty() { return outstanding; }
    
    public int getReturnQuantity() { return returnQuantity.get(); }
    public void setReturnQuantity(int value) { returnQuantity.set(value); }
    public IntegerProperty returnQuantityProperty() { return returnQuantity; }
}
