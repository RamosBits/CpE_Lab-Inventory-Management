package cpe_lab_inventory;

public class Transaction {
    private int transactionId;
    private String studentId;
    private String studentName;
    private int itemId;
    private String itemName;
    private int quantity;
    private int quantityReturned;
    private int orNumber;
    private String status;
    private String timestamp;
    private String returnDate;

    public Transaction(int transactionId, String studentId, String studentName, int itemId, String itemName, String status, String timestamp) {
        this.transactionId = transactionId;
        this.studentId = studentId;
        this.studentName = studentName;
        this.itemId = itemId;
        this.itemName = itemName;
        this.quantity = 0;
        this.quantityReturned = 0;
        this.orNumber = 0;
        this.status = status;
        this.timestamp = timestamp;
        this.returnDate = null;
    }

    public Transaction(int transactionId, String studentId, String studentName, int itemId, String itemName, int quantity, int orNumber, String status, String timestamp) {
        this.transactionId = transactionId;
        this.studentId = studentId;
        this.studentName = studentName;
        this.itemId = itemId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.quantityReturned = 0;
        this.orNumber = orNumber;
        this.status = status;
        this.timestamp = timestamp;
        this.returnDate = null;
    }

    public Transaction(int transactionId, String studentId, String studentName, int itemId, String itemName, int quantity, int quantityReturned, int orNumber, String status, String timestamp) {
        this.transactionId = transactionId;
        this.studentId = studentId;
        this.studentName = studentName;
        this.itemId = itemId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.quantityReturned = quantityReturned;
        this.orNumber = orNumber;
        this.status = status;
        this.timestamp = timestamp;
        this.returnDate = null;
    }

    public Transaction(int transactionId, String studentId, String studentName, int itemId, String itemName, int quantity, int quantityReturned, int orNumber, String status, String timestamp, String returnDate) {
        this.transactionId = transactionId;
        this.studentId = studentId;
        this.studentName = studentName;
        this.itemId = itemId;
        this.itemName = itemName;
        this.quantity = quantity;
        this.quantityReturned = quantityReturned;
        this.orNumber = orNumber;
        this.status = status;
        this.timestamp = timestamp;
        this.returnDate = returnDate;
    }

    public int getTransactionId() { return transactionId; }
    public String getStudentId() { return studentId; }
    public String getStudentName() { return studentName; }
    public int getItemId() { return itemId; }
    public String getItemName() { return itemName; }
    public int getQuantity() { return quantity; }
    public int getQuantityReturned() { return quantityReturned; }
    public int getOutstandingQuantity() { return quantity - quantityReturned; }
    public int getOrNumber() { return orNumber; }
    public String getStatus() {
        // Handle different status formats
        if (status == null) return "";
        // Database storage (full names)
        if (status.equalsIgnoreCase("Borrowed")) return "Borrowed";
        if (status.equalsIgnoreCase("Partially Returned")) return "Partially Returned";
        if (status.equalsIgnoreCase("Returned")) return "Returned";
        if (status.equalsIgnoreCase("Overdue")) return "Overdue";
        // Short codes (legacy)
        if (status.equalsIgnoreCase("B")) return "Borrowed";
        if (status.equalsIgnoreCase("PR")) return "Partially Returned";
        if (status.equalsIgnoreCase("R")) return "Returned";
        if (status.equalsIgnoreCase("O")) return "Overdue";
        // Present tense (UI input)
        if (status.equalsIgnoreCase("Borrow")) return "Borrowed";
        if (status.equalsIgnoreCase("Return")) return "Returned";
        return status;
    }
    public String getTimestamp() { return timestamp; }
    public String getReturnDate() { return returnDate; }
}
