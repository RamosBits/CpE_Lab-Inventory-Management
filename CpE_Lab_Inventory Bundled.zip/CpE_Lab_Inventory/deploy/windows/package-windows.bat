@echo off
setlocal
cd /d "%~dp0..\.."

REM Run build-windows.bat first.
set APP_NAME=CpE Lab Inventory
set MAIN_CLASS=cpe_lab_inventory.MainApp
set JAVAFX_LIB=C:\JavaFX\javafx-sdk-25.0.2\lib
set MYSQL_JAR=dist\manual\lib\mysql-connector-j-8.0.33.jar
set APP_JAR=dist\manual\CpE_Lab_Inventory.jar

jpackage ^
  --type app-image ^
  --name "%APP_NAME%" ^
  --input dist\manual ^
  --main-jar CpE_Lab_Inventory.jar ^
  --main-class "%MAIN_CLASS%" ^
  --module-path "%JAVAFX_LIB%" ^
  --add-modules javafx.controls,javafx.fxml ^
  --app-version 1.0 ^
  --dest dist\installer

echo App image created in dist\installer
endlocal
