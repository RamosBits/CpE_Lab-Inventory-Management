@echo off
setlocal
cd /d "%~dp0..\.."

set APP_NAME=CpE_Lab_Inventory
set MAIN_CLASS=cpe_lab_inventory.MainApp

REM Change JAVAFX_LIB if your JavaFX SDK is somewhere else.
if defined JAVAFX_HOME (
  set JAVAFX_LIB=%JAVAFX_HOME%\lib
) else (
  set JAVAFX_LIB=C:\JavaFX\javafx-sdk-25.0.2\lib
)
if not exist "%JAVAFX_LIB%\javafx.controls.jar" (
  if exist "C:\JavaFX\javafx-sdk-25.0.3\lib\javafx.controls.jar" (
    set JAVAFX_LIB=C:\JavaFX\javafx-sdk-25.0.3\lib
  )
)

REM Prefer a connector jar inside this project folder.
set MYSQL_JAR=lib\mysql-connector-j-8.0.33.jar
if not exist "%MYSQL_JAR%" (
  set MYSQL_JAR=dist\manual\lib\mysql-connector-j-8.0.33.jar
)
if not exist "%MYSQL_JAR%" (
  set MYSQL_JAR=C:\CpE_Lab_Inventory\lib\mysql-connector-j-8.0.33.jar
)

set OUT_DIR=dist\manual
set CLASSES_DIR=%OUT_DIR%\classes

where javac >nul 2>nul
if errorlevel 1 (
  echo ERROR: javac was not found. Install a JDK and reopen Command Prompt.
  goto fail
)

where jar >nul 2>nul
if errorlevel 1 (
  echo ERROR: jar was not found. Install a JDK and reopen Command Prompt.
  goto fail
)

if not exist "%JAVAFX_LIB%\javafx.controls.jar" (
  echo ERROR: JavaFX was not found at:
  echo %JAVAFX_LIB%
  echo Edit JAVAFX_LIB in this file to match your JavaFX SDK path.
  goto fail
)

if not exist "%MYSQL_JAR%" (
  echo ERROR: MySQL Connector/J was not found.
  echo Put mysql-connector-j-8.0.33.jar in this project's lib folder, or edit MYSQL_JAR.
  goto fail
)

if not exist "%CLASSES_DIR%\cpe_lab_inventory" mkdir "%CLASSES_DIR%\cpe_lab_inventory"
if not exist "%OUT_DIR%\lib" mkdir "%OUT_DIR%\lib"

echo Using JavaFX: %JAVAFX_LIB%
echo Using MySQL Connector/J: %MYSQL_JAR%
echo.

javac ^
  --module-path "%JAVAFX_LIB%" ^
  --add-modules javafx.controls,javafx.fxml ^
  -cp "%MYSQL_JAR%" ^
  -d "%CLASSES_DIR%" ^
  src\cpe_lab_inventory\*.java
if errorlevel 1 goto fail

copy src\cpe_lab_inventory\*.fxml "%CLASSES_DIR%\cpe_lab_inventory\"
if errorlevel 1 goto fail

if /i "%MYSQL_JAR%"=="dist\manual\lib\mysql-connector-j-8.0.33.jar" (
  echo MySQL Connector/J is already in %OUT_DIR%\lib
) else (
  copy "%MYSQL_JAR%" "%OUT_DIR%\lib\"
  if errorlevel 1 goto fail
)

jar --create ^
  --file "%OUT_DIR%\%APP_NAME%.jar" ^
  --manifest deploy\MANIFEST.MF ^
  -C "%CLASSES_DIR%" .
if errorlevel 1 goto fail

echo Built %OUT_DIR%\%APP_NAME%.jar
echo.
pause
endlocal
exit /b 0

:fail
echo.
echo Build failed. Read the error above.
pause
endlocal
exit /b 1
