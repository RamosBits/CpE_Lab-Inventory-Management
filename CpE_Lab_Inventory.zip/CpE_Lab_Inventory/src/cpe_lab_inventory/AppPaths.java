package cpe_lab_inventory;

import java.io.File;

public class AppPaths {
    private static final String APP_FOLDER = "CpE Lab Inventory";

    public static File getReceiptsDirectory() {
        return getOutputDirectory("Receipts");
    }

    public static File getReportsDirectory() {
        return getOutputDirectory("Reports");
    }

    private static File getOutputDirectory(String childFolder) {
        File documents = new File(System.getProperty("user.home"), "Documents");
        File base = documents.exists()
            ? new File(documents, APP_FOLDER)
            : new File(System.getProperty("user.home"), APP_FOLDER);

        File outputDirectory = new File(base, childFolder);
        if (!outputDirectory.exists()) {
            outputDirectory.mkdirs();
        }

        return outputDirectory;
    }
}
