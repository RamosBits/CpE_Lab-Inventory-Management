@echo off
setlocal
cd /d "%~dp0..\.."

if defined JAVAFX_HOME (
  set JAVAFX_LIB=%JAVAFX_HOME%\lib
) else (
  set JAVAFX_LIB=C:\JavaFX\javafx-sdk-25.0.2\lib
)
if not exist "%JAVAFX_LIB%\javafx.controls.jar" (
  if exist "C:\JavaFX\javafx-sdk-25.0.3\lib\javafx.controls.jar" (
    set JAVAFX_LIB=C:\JavaFX\javafx-sdk-25.0.3\lib
  )
)
set MYSQL_JAR=dist\manual\lib\mysql-connector-j-8.0.33.jar
set APP_JAR=dist\manual\CpE_Lab_Inventory.jar

where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: java was not found. Install a JDK and reopen Command Prompt.
  goto fail
)

if not exist "%JAVAFX_LIB%\javafx.controls.jar" (
  echo ERROR: JavaFX was not found at:
  echo %JAVAFX_LIB%
  echo Edit JAVAFX_LIB in this file to match your JavaFX SDK path.
  goto fail
)

if not exist "%APP_JAR%" (
  echo ERROR: App jar was not found:
  echo %APP_JAR%
  echo Run deploy\windows\build-windows.bat first.
  goto fail
)

if not exist "%MYSQL_JAR%" (
  echo ERROR: MySQL Connector/J was not found:
  echo %MYSQL_JAR%
  echo Run deploy\windows\build-windows.bat first.
  goto fail
)

java ^
  --module-path "%JAVAFX_LIB%" ^
  --add-modules javafx.controls,javafx.fxml ^
  -cp "%APP_JAR%;%MYSQL_JAR%" ^
  cpe_lab_inventory.MainApp
if errorlevel 1 goto fail

echo.
pause
endlocal
exit /b 0

:fail
echo.
echo Run failed. Read the error above.
pause
endlocal
exit /b 1
