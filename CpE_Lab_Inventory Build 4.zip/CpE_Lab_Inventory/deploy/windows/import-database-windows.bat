@echo off
setlocal
cd /d "%~dp0..\.."

set DB_NAME=cpelab_db
set DB_USER=root
set DB_PASS=root
set SQL_FILE=database-backup\cpelab_db.sql

where mysql >nul 2>nul
if errorlevel 1 (
  echo ERROR: mysql was not found.
  echo Add MySQL Server bin folder to PATH, then reopen Command Prompt.
  goto fail
)

if not exist "%SQL_FILE%" (
  echo ERROR: SQL backup file was not found:
  echo %SQL_FILE%
  echo Copy cpelab_db.sql into the database-backup folder first.
  goto fail
)

mysql -u %DB_USER% -p%DB_PASS% -e "CREATE DATABASE IF NOT EXISTS %DB_NAME%;"
if errorlevel 1 goto fail

mysql -u %DB_USER% -p%DB_PASS% %DB_NAME% < "%SQL_FILE%"
if errorlevel 1 goto fail

echo Imported %SQL_FILE% into %DB_NAME%
echo.
pause
endlocal
exit /b 0

:fail
echo.
echo Database import failed. Read the error above.
pause
endlocal
exit /b 1
