package cpe_lab_inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;

public class TransactionsController extends BaseModuleController {
    @FXML
    private TableView<Transaction> transactionsTable;
    @FXML
    private TableView<TransactionItem> selectedItemsTable;
    @FXML
    private TextField studentDisplayField;
    @FXML
    private TextField itemDisplayField;
    @FXML
    private TextField quantityField;
    @FXML
    private Label orNumberLabel;
    
    @FXML
    private TableColumn<Transaction, Integer> orNumberColumn;
    @FXML
    private TableColumn<Transaction, String> studentColumn;
    @FXML
    private TableColumn<Transaction, String> itemColumn;
    @FXML
    private TableColumn<Transaction, Integer> quantityBorrowedColumn;
    @FXML
    private TableColumn<Transaction, Integer> quantityReturnedColumn;
    @FXML
    private TableColumn<Transaction, Integer> quantityColumn;
    @FXML
    private TableColumn<Transaction, String> statusColumn;
    @FXML
    private TableColumn<Transaction, String> dateColumn;
    @FXML
    private TableColumn<Transaction, String> returnDateColumn;
    @FXML
    private TableColumn<Transaction, String> actionColumn;
    
    @FXML
    private TableColumn<TransactionItem, String> selectedItemNameColumn;
    @FXML
    private TableColumn<TransactionItem, Integer> selectedQuantityColumn;
    @FXML
    private TableColumn<TransactionItem, String> selectedActionColumn;

    private ObservableList<TransactionItem> pendingItems = FXCollections.observableArrayList();
    private int currentOrNumber;
    private Student selectedStudent;
    private Item selectedItem;
    @FXML
    private TextField searchORField;
    private ObservableList<Transaction> allTransactions;

    @FXML
    public void initialize() {
        setupTransactionsTableColumns();
        setupSelectedItemsTableColumns();
        
        loadTransactionsTable();
        generateNewOrNumber();
    }

    private void setupTransactionsTableColumns() {
        orNumberColumn.setCellValueFactory(new PropertyValueFactory<>("orNumber"));
        studentColumn.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        itemColumn.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        quantityBorrowedColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        quantityReturnedColumn.setCellValueFactory(new PropertyValueFactory<>("quantityReturned"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("outstandingQuantity"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("timestamp"));
        returnDateColumn.setCellValueFactory(new PropertyValueFactory<>("returnDate"));
        
        // Setup action column with both Return and Delete buttons
        actionColumn.setCellFactory(param -> new TableCell<Transaction, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    Transaction transaction = getTableView().getItems().get(getIndex());
                    String status = transaction.getStatus();
                    
                    HBox actionBox = new HBox(5);
                    actionBox.setAlignment(Pos.CENTER);
                    
                    // Return button - only for Borrowed or Partially Returned
                    if ("Borrowed".equalsIgnoreCase(status) || "Partially Returned".equalsIgnoreCase(status)) {
                        Button returnBtn = new Button("Return");
                        returnBtn.setStyle("-fx-padding: 5 10; -fx-background-color: #2196F3; -fx-text-fill: white; -fx-cursor: hand; -fx-font-size: 10;");
                        returnBtn.setOnAction(event -> handleReturnItem(transaction));
                        actionBox.getChildren().add(returnBtn);
                    }
                    
                    // Delete button - only for Borrowed or Partially Returned (not for fully Returned)
                    if ("Borrowed".equalsIgnoreCase(status) || "Partially Returned".equalsIgnoreCase(status)) {
                        Button deleteBtn = new Button("Delete");
                        deleteBtn.setStyle("-fx-padding: 5 10; -fx-background-color: #d32f2f; -fx-text-fill: white; -fx-cursor: hand; -fx-font-size: 10;");
                        deleteBtn.setOnAction(event -> handleDeleteTransaction(transaction));
                        actionBox.getChildren().add(deleteBtn);
                    }
                    
                    setGraphic(actionBox);
                }
            }
        });
    }

    private void setupSelectedItemsTableColumns() {
        selectedItemNameColumn.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        selectedQuantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        
        // Add action column for removing items
        selectedActionColumn.setCellFactory(param -> new TableCell<TransactionItem, String>() {
            private final Button btn = new Button("Remove");
            
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    btn.setStyle("-fx-padding: 5 10; -fx-background-color: #d32f2f; -fx-text-fill: white; -fx-cursor: hand;");
                    btn.setOnAction(event -> {
                        TransactionItem toRemove = selectedItemsTable.getSelectionModel().getSelectedItem();
                        if (toRemove != null) {
                            pendingItems.remove(toRemove);
                            selectedItemsTable.setItems(pendingItems);
                        }
                    });
                    setGraphic(btn);
                }
            }
        });
    }

    private void generateNewOrNumber() {
        currentOrNumber = DatabaseManager.getNextOrNumber();
        orNumberLabel.setText("OR #: " + currentOrNumber);
    }

    @FXML
    private void handleSelectStudent() {
        Student student = StudentSelectionDialogController.showStudentSelectionDialog();
        if (student != null) {
            selectedStudent = student;
            studentDisplayField.setText(student.getStudentId() + " - " + student.getName());
        }
    }

    @FXML
    private void handleClearStudent() {
        selectedStudent = null;
        studentDisplayField.clear();
    }

    @FXML
    private void handleSelectItem() {
        Item item = ItemSelectionDialogController.showItemSelectionDialog();
        if (item != null) {
            selectedItem = item;
            itemDisplayField.setText(item.getItemId() + " - " + item.getItemName() + " (" + item.getCurrentStock() + " available)");
        }
    }

    public void loadTransactionsTable() {
        try {
            allTransactions = DatabaseManager.getAllTransactions();
            transactionsTable.setItems(allTransactions);
        } catch (Exception e) {
            showAlert("Database Error", "Failed to load transactions table: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleSearchOR() {
        String searchText = searchORField.getText().trim();
        
        if (searchText.isEmpty()) {
            transactionsTable.setItems(allTransactions);
            return;
        }

        ObservableList<Transaction> filteredTransactions = FXCollections.observableArrayList();
        for (Transaction transaction : allTransactions) {
            if (String.valueOf(transaction.getOrNumber()).contains(searchText)) {
                filteredTransactions.add(transaction);
            }
        }
        transactionsTable.setItems(filteredTransactions);
    }

    @FXML
    private void handleClearSearchOR() {
        searchORField.clear();
        transactionsTable.setItems(allTransactions);
    }

    @FXML
    private void handleBulkReturn() {
        BulkReturnDialogController.showBulkReturnDialog(currentUser);
        // Refresh table after bulk return
        loadTransactionsTable();
    }

    @FXML
    private void handleAddItemToTransaction() {
        String quantityStr = quantityField.getText().trim();

        if (selectedItem == null) {
            showAlert("Validation Error", "Please select an item.", Alert.AlertType.WARNING);
            return;
        }

        if (quantityStr.isEmpty()) {
            showAlert("Validation Error", "Please enter a quantity.", Alert.AlertType.WARNING);
            return;
        }

        try {
            int quantity = Integer.parseInt(quantityStr);
            if (quantity <= 0) {
                showAlert("Validation Error", "Quantity must be greater than 0.", Alert.AlertType.WARNING);
                return;
            }

            // Check if item already exists in pending list
            for (TransactionItem item : pendingItems) {
                if (item.getItemId() == selectedItem.getItemId()) {
                    showAlert("Duplicate Item", "This item is already in the transaction. Remove it first to change quantity.", Alert.AlertType.WARNING);
                    return;
                }
            }

            TransactionItem newItem = new TransactionItem(selectedItem.getItemId(), selectedItem.getItemName(), quantity);
            pendingItems.add(newItem);
            selectedItemsTable.setItems(pendingItems);

            // Clear input fields
            selectedItem = null;
            itemDisplayField.clear();
            quantityField.clear();
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Quantity must be a valid number.", Alert.AlertType.ERROR);
        } catch (Exception e) {
            showAlert("Error", "Error adding item: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleSubmitTransaction() {
        if (selectedStudent == null) {
            showAlert("Validation Error", "Please select a student.", Alert.AlertType.WARNING);
            return;
        }

        if (pendingItems.isEmpty()) {
            showAlert("Validation Error", "Please add at least one item to the transaction.", Alert.AlertType.WARNING);
            return;
        }

        try {
            // Default to "Borrow" - returns are handled through the Return Item button
            String transactionType = "Borrow";

            // Add all items with the same OR number
            boolean allSuccess = true;
            for (TransactionItem item : pendingItems) {
                boolean success = DatabaseManager.addTransaction(
                    selectedStudent.getStudentId(),
                    currentUser.getUserId(),
                    String.valueOf(item.getItemId()),
                    item.getQuantity(),
                    currentOrNumber,
                    transactionType
                );
                if (!success) {
                    allSuccess = false;
                }
            }

            if (allSuccess) {
                // Auto-generate and save receipt
                java.util.List<TransactionItem> itemsForReceipt = new java.util.ArrayList<>(pendingItems);
                TransactionReceiptGenerator.generateTransactionReceipt(
                    currentOrNumber, 
                    selectedStudent, 
                    itemsForReceipt, 
                    currentUser
                );
                
                clearTransaction();
                loadTransactionsTable();
            } else {
                showAlert("Partial Error", "Some items failed to be added. Check database logs.", Alert.AlertType.WARNING);
            }
        } catch (Exception e) {
            showAlert("Error", "Error submitting transaction: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleClearTransaction() {
        pendingItems.clear();
        selectedItemsTable.setItems(pendingItems);
        selectedStudent = null;
        selectedItem = null;
        studentDisplayField.clear();
        itemDisplayField.clear();
        quantityField.clear();
        generateNewOrNumber();
    }

    private void clearTransaction() {
        pendingItems.clear();
        selectedItemsTable.setItems(pendingItems);
        selectedItem = null;
        itemDisplayField.clear();
        quantityField.clear();
        generateNewOrNumber();
    }

    private void handleReturnItem(Transaction transaction) {
        try {
            // Get the item details
            ObservableList<Item> allItems = DatabaseManager.getAllItems();
            Item selectedItem = null;
            for (Item item : allItems) {
                if (item.getItemId() == transaction.getItemId()) {
                    selectedItem = item;
                    break;
                }
            }

            if (selectedItem == null) {
                showAlert("Error", "Item not found in inventory.", Alert.AlertType.ERROR);
                return;
            }

            // Create return details for dialog
            ReturnDetails returnDetails = new ReturnDetails();
            returnDetails.setTransactionId(transaction.getTransactionId());
            returnDetails.setItemName(transaction.getItemName());
            returnDetails.setItemType(selectedItem.getType());
            returnDetails.setQuantityBorrowed(transaction.getQuantity());

            // Show return dialog
            Integer quantityReturned = ReturnItemDialogController.showReturnDialog(transaction, selectedItem);

            if (quantityReturned != null && quantityReturned > 0) {
                // Process the return
                boolean success = DatabaseManager.returnItem(transaction.getTransactionId(), quantityReturned);
                
                if (success) {
                    // Auto-generate return receipt
                    java.util.List<TransactionItem> returnItems = new java.util.ArrayList<>();
                    TransactionItem returnItem = new TransactionItem(
                        transaction.getItemId(),
                        transaction.getItemName(),
                        quantityReturned
                    );
                    returnItems.add(returnItem);
                    
                    // Get student info from database
                    ObservableList<Student> allStudents = DatabaseManager.getAllStudents();
                    Student returnStudent = null;
                    for (Student student : allStudents) {
                        if (student.getStudentId().equals(transaction.getStudentId())) {
                            returnStudent = student;
                            break;
                        }
                    }
                    
                    if (returnStudent != null) {
                        TransactionReceiptGenerator.generateTransactionReceipt(
                            transaction.getOrNumber(),
                            returnStudent,
                            returnItems,
                            currentUser
                        );
                    }
                    
                    loadTransactionsTable();
                } else {
                    showAlert("Error", "Failed to process return. Please try again.", Alert.AlertType.ERROR);
                }
            }
        } catch (Exception e) {
            showAlert("Error", "Error processing return: " + e.getMessage(), Alert.AlertType.ERROR);
            e.printStackTrace();
        }
    }

    private void handleDeleteTransaction(Transaction transaction) {
        // Confirmation dialog
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Delete Transaction");
        confirmAlert.setHeaderText("Delete Transaction?");
        confirmAlert.setContentText("Are you sure you want to delete this transaction?\n(OR #: " + transaction.getOrNumber() + ", Student: " + transaction.getStudentName() + ")\n\nThis action cannot be undone.");
        
        if (confirmAlert.showAndWait().get() == ButtonType.OK) {
            try {
                boolean success = DatabaseManager.deleteTransaction(transaction.getTransactionId());
                
                if (success) {
                    showAlert("Success", "Transaction deleted successfully!", Alert.AlertType.INFORMATION);
                    loadTransactionsTable();
                } else {
                    showAlert("Error", "Failed to delete transaction. Please try again.", Alert.AlertType.ERROR);
                }
            } catch (Exception e) {
                showAlert("Error", "Error deleting transaction: " + e.getMessage(), Alert.AlertType.ERROR);
                e.printStackTrace();
            }
        }
    }
}
