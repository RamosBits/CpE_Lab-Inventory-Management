package cpe_lab_inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.util.*;

public class BulkReturnDialogController {
    @FXML
    private TextField searchField;
    @FXML
    private Label orNumberLabel;
    @FXML
    private Label studentNameLabel;
    @FXML
    private TableView<BulkReturnItem> itemsTable;
    @FXML
    private TableColumn<BulkReturnItem, String> itemNameColumn;
    @FXML
    private TableColumn<BulkReturnItem, Integer> quantityBorrowedColumn;
    @FXML
    private TableColumn<BulkReturnItem, Integer> quantityReturnedColumn;
    @FXML
    private TableColumn<BulkReturnItem, Integer> outstandingColumn;
    @FXML
    private TableColumn<BulkReturnItem, Integer> returnQuantityColumn;
    @FXML
    private Label messageLabel;
    
    private Stage dialogStage;
    private User currentUser;
    private ObservableList<BulkReturnItem> bulkReturnItems = FXCollections.observableArrayList();
    private int selectedOrNumber = -1;
    private Student selectedStudent = null;

    @FXML
    public void initialize() {
        setupTableColumns();
    }

    private void setupTableColumns() {
        itemNameColumn.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        quantityBorrowedColumn.setCellValueFactory(new PropertyValueFactory<>("quantityBorrowed"));
        quantityReturnedColumn.setCellValueFactory(new PropertyValueFactory<>("quantityReturned"));
        outstandingColumn.setCellValueFactory(new PropertyValueFactory<>("outstanding"));
        
        // Return Quantity column with spinners
        returnQuantityColumn.setCellFactory(param -> new TableCell<BulkReturnItem, Integer>() {
            private final Spinner<Integer> spinner = new Spinner<>();
            
            @Override
            protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    BulkReturnItem returnItem = getTableView().getItems().get(getIndex());
                    int maxReturn = returnItem.getOutstanding();
                    
                    SpinnerValueFactory<Integer> valueFactory = 
                        new SpinnerValueFactory.IntegerSpinnerValueFactory(0, maxReturn, 0);
                    spinner.setValueFactory(valueFactory);
                    spinner.setPrefWidth(100);
                    
                    // Update the model when spinner changes
                    spinner.valueProperty().addListener((obs, oldVal, newVal) -> {
                        returnItem.setReturnQuantity(newVal);
                    });
                    
                    setGraphic(spinner);
                }
            }
        });
        
        itemsTable.setItems(bulkReturnItems);
    }

    @FXML
    private void handleSearch() {
        String searchTerm = searchField.getText().trim();
        if (searchTerm.isEmpty()) {
            messageLabel.setText("Please enter an OR# or Student name to search.");
            return;
        }
        
        bulkReturnItems.clear();
        
        // Try to parse as OR number first
        try {
            int orNumber = Integer.parseInt(searchTerm);
            searchByOrNumber(orNumber);
        } catch (NumberFormatException e) {
            // Not a number, search by student name
            searchByStudentName(searchTerm);
        }
        
        if (bulkReturnItems.isEmpty()) {
            messageLabel.setText("No items found for the search criteria.");
        } else {
            messageLabel.setText("");
        }
    }

    private void searchByOrNumber(int orNumber) {
        ObservableList<Transaction> allTransactions = DatabaseManager.getAllTransactions();
        Student student = null;
        
        for (Transaction transaction : allTransactions) {
            if (transaction.getOrNumber() == orNumber) {
                if (student == null) {
                    // Get student info from first transaction with this OR
                    ObservableList<Student> allStudents = DatabaseManager.getAllStudents();
                    for (Student s : allStudents) {
                        if (s.getStudentId().equals(transaction.getStudentId())) {
                            student = s;
                            break;
                        }
                    }
                }
                
                // Only add if there's still outstanding quantity
                int outstanding = transaction.getOutstandingQuantity();
                if (outstanding > 0) {
                    BulkReturnItem item = new BulkReturnItem(
                        transaction.getTransactionId(),
                        transaction.getItemId(),
                        transaction.getItemName(),
                        transaction.getQuantity(),
                        transaction.getQuantityReturned(),
                        outstanding
                    );
                    bulkReturnItems.add(item);
                }
            }
        }
        
        if (student != null) {
            selectedOrNumber = orNumber;
            selectedStudent = student;
            orNumberLabel.setText("OR #: " + orNumber);
            studentNameLabel.setText("Student: " + student.getName());
        }
    }

    private void searchByStudentName(String studentName) {
        ObservableList<Student> allStudents = DatabaseManager.getAllStudents();
        Student foundStudent = null;
        
        // Search for student by name or ID
        for (Student student : allStudents) {
            if (student.getName().toLowerCase().contains(studentName.toLowerCase()) ||
                student.getStudentId().toLowerCase().contains(studentName.toLowerCase())) {
                foundStudent = student;
                break;
            }
        }
        
        if (foundStudent != null) {
            ObservableList<Transaction> allTransactions = DatabaseManager.getAllTransactions();
            Integer lastOrNumber = null;
            
            for (Transaction transaction : allTransactions) {
                if (transaction.getStudentId().equals(foundStudent.getStudentId())) {
                    if (lastOrNumber == null || lastOrNumber != transaction.getOrNumber()) {
                        lastOrNumber = transaction.getOrNumber();
                    }
                    
                    // Only add if there's still outstanding quantity
                    int outstanding = transaction.getOutstandingQuantity();
                    if (outstanding > 0) {
                        BulkReturnItem item = new BulkReturnItem(
                            transaction.getTransactionId(),
                            transaction.getItemId(),
                            transaction.getItemName(),
                            transaction.getQuantity(),
                            transaction.getQuantityReturned(),
                            outstanding
                        );
                        bulkReturnItems.add(item);
                    }
                }
            }
            
            selectedStudent = foundStudent;
            selectedOrNumber = lastOrNumber != null ? lastOrNumber : -1;
            orNumberLabel.setText("OR #: " + (lastOrNumber != null ? lastOrNumber : "Multiple"));
            studentNameLabel.setText("Student: " + foundStudent.getName());
        }
    }

    @FXML
    private void handleClear() {
        searchField.clear();
        bulkReturnItems.clear();
        orNumberLabel.setText("OR #: ---");
        studentNameLabel.setText("Student: ---");
        messageLabel.setText("");
        selectedOrNumber = -1;
        selectedStudent = null;
    }

    @FXML
    private void handleProcessReturns() {
        // Collect items that need to be returned
        List<BulkReturnItem> itemsToReturn = new ArrayList<>();
        for (BulkReturnItem item : bulkReturnItems) {
            if (item.getReturnQuantity() > 0) {
                itemsToReturn.add(item);
            }
        }
        
        if (itemsToReturn.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Items Selected");
            alert.setHeaderText("No items selected for return");
            alert.setContentText("Please select at least one item and specify the quantity to return.");
            alert.showAndWait();
            return;
        }
        
        // Process all returns
        boolean allSuccess = true;
        List<TransactionItem> receiptItems = new ArrayList<>();
        
        for (BulkReturnItem item : itemsToReturn) {
            boolean success = DatabaseManager.returnItem(item.getTransactionId(), item.getReturnQuantity());
            if (!success) {
                allSuccess = false;
            } else {
                // Add to receipt items
                TransactionItem receiptItem = new TransactionItem(
                    item.getItemId(),
                    item.getItemName(),
                    item.getReturnQuantity()
                );
                receiptItems.add(receiptItem);
            }
        }
        
        if (allSuccess && !receiptItems.isEmpty()) {
            // Generate combined receipt
            TransactionReceiptGenerator.generateTransactionReceipt(
                selectedOrNumber,
                selectedStudent,
                receiptItems,
                currentUser
            );
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText("Returns Processed");
            alert.setContentText("All items have been returned successfully!");
            alert.showAndWait();
            
            dialogStage.close();
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Some items failed to process");
            alert.setContentText("Please check the database and try again.");
            alert.showAndWait();
        }
    }

    @FXML
    private void handleClose() {
        dialogStage.close();
    }

    public void setDialogStage(Stage stage) {
        this.dialogStage = stage;
    }

    public void setCurrentUser(User user) {
        this.currentUser = user;
    }

    public static void showBulkReturnDialog(User currentUser) {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                BulkReturnDialogController.class.getResource("BulkReturnDialog.fxml")
            );
            javafx.scene.Parent root = loader.load();
            BulkReturnDialogController controller = loader.getController();
            controller.setCurrentUser(currentUser);
            
            Stage stage = new Stage();
            stage.setTitle("Bulk Return Items");
            stage.setScene(new javafx.scene.Scene(root, 900, 600));
            controller.setDialogStage(stage);
            
            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
