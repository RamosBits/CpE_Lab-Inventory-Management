package cpe_lab_inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ItemTransactionHistoryController {
    @FXML
    private Label itemNameLabel;
    @FXML
    private Label itemIdLabel;
    @FXML
    private TableView<ItemTransactionHistoryItem> historyTable;
    @FXML
    private TableColumn<ItemTransactionHistoryItem, Integer> orNumberColumn;
    @FXML
    private TableColumn<ItemTransactionHistoryItem, String> studentIdColumn;
    @FXML
    private TableColumn<ItemTransactionHistoryItem, String> studentNameColumn;
    @FXML
    private TableColumn<ItemTransactionHistoryItem, Integer> quantityColumn;
    @FXML
    private TableColumn<ItemTransactionHistoryItem, String> statusColumn;
    @FXML
    private TableColumn<ItemTransactionHistoryItem, String> borrowDateColumn;
    @FXML
    private TableColumn<ItemTransactionHistoryItem, String> returnDateColumn;
    @FXML
    private TableColumn<ItemTransactionHistoryItem, String> encoderColumn;
    @FXML
    private Label messageLabel;
    
    private Stage dialogStage;
    private int itemId;
    private ObservableList<ItemTransactionHistoryItem> historyItems = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        setupTableColumns();
    }

    private void setupTableColumns() {
        orNumberColumn.setCellValueFactory(new PropertyValueFactory<>("orNumber"));
        studentIdColumn.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        studentNameColumn.setCellValueFactory(new PropertyValueFactory<>("studentName"));
        quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        borrowDateColumn.setCellValueFactory(new PropertyValueFactory<>("borrowDate"));
        returnDateColumn.setCellValueFactory(new PropertyValueFactory<>("returnDate"));
        encoderColumn.setCellValueFactory(new PropertyValueFactory<>("encoderName"));
        
        historyTable.setItems(historyItems);
    }

    public void loadItemTransactionHistory(int itemId, String itemName) {
        this.itemId = itemId;
        itemIdLabel.setText(String.valueOf(itemId));
        itemNameLabel.setText(itemName);
        
        historyItems.clear();
        
        // Fetch all transactions for this item
        ObservableList<Transaction> allTransactions = DatabaseManager.getAllTransactions();
        
        for (Transaction transaction : allTransactions) {
            if (transaction.getItemId() == itemId) {
                // Get encoder name from database
                String encoderName = getEncoderName(transaction.getTransactionId());
                
                ItemTransactionHistoryItem historyItem = new ItemTransactionHistoryItem(
                    transaction.getOrNumber(),
                    transaction.getStudentId(),
                    transaction.getStudentName(),
                    transaction.getQuantity(),
                    transaction.getStatus(),
                    transaction.getTimestamp(),
                    transaction.getReturnDate(),
                    encoderName
                );
                historyItems.add(historyItem);
            }
        }
        
        if (historyItems.isEmpty()) {
            messageLabel.setText("No transaction history found for this item.");
        } else {
            messageLabel.setText("");
        }
    }

    private String getEncoderName(int transactionId) {
        // Query database to get encoder's name from users table
        try {
            java.sql.Connection conn = DatabaseManager.getConnection();
            String query = "SELECT u.f_name, u.l_name FROM transactions t LEFT JOIN users u ON t.encoder_id = u.user_id WHERE t.transaction_id = ?";
            java.sql.PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, transactionId);
            java.sql.ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                String fName = rs.getString("f_name");
                String lName = rs.getString("l_name");
                return (fName != null ? fName : "") + " " + (lName != null ? lName : "");
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "Unknown";
    }

    @FXML
    private void handleClose() {
        dialogStage.close();
    }

    public void setDialogStage(Stage stage) {
        this.dialogStage = stage;
    }

    public static void showItemTransactionHistory(int itemId, String itemName) {
        try {
            javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(
                ItemTransactionHistoryController.class.getResource("ItemTransactionHistory.fxml")
            );
            javafx.scene.Parent root = loader.load();
            ItemTransactionHistoryController controller = loader.getController();
            controller.loadItemTransactionHistory(itemId, itemName);
            
            Stage stage = new Stage();
            stage.setTitle("Transaction History - Item: " + itemName);
            stage.setScene(new javafx.scene.Scene(root, 1000, 700));
            controller.setDialogStage(stage);
            
            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
