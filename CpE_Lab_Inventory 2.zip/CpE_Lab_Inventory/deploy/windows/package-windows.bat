@echo off
setlocal
cd /d "%~dp0..\.."

REM Run build-windows.bat first.
set APP_NAME=CpE Lab Inventory
set MAIN_CLASS=cpe_lab_inventory.MainApp
set JAVAFX_LIB=C:\JavaFX\javafx-sdk-25.0.2\lib
set MYSQL_JAR=dist\manual\lib\mysql-connector-j-8.0.33.jar
set APP_JAR=dist\manual\CpE_Lab_Inventory.jar

where jpackage >nul 2>nul
if errorlevel 1 (
  echo ERROR: jpackage was not found. Install a JDK that includes jpackage.
  echo Then reopen Command Prompt and try again.
  goto fail
)

if not exist "%JAVAFX_LIB%\javafx.controls.jar" (
  echo ERROR: JavaFX was not found at:
  echo %JAVAFX_LIB%
  echo Edit JAVAFX_LIB in this file to match your JavaFX SDK path.
  goto fail
)

if not exist "%APP_JAR%" (
  echo ERROR: App jar was not found:
  echo %APP_JAR%
  echo Run deploy\windows\build-windows.bat first.
  goto fail
)

if not exist "%MYSQL_JAR%" (
  echo ERROR: MySQL Connector/J was not found:
  echo %MYSQL_JAR%
  echo Run deploy\windows\build-windows.bat first.
  goto fail
)

jpackage ^
  --type app-image ^
  --name "%APP_NAME%" ^
  --input dist\manual ^
  --main-jar CpE_Lab_Inventory.jar ^
  --main-class "%MAIN_CLASS%" ^
  --module-path "%JAVAFX_LIB%" ^
  --add-modules javafx.controls,javafx.fxml ^
  --app-version 1.0 ^
  --dest dist\installer
if errorlevel 1 goto fail

echo App image created in dist\installer
echo.
pause
endlocal
exit /b 0

:fail
echo.
echo Packaging failed. Read the error above.
pause
endlocal
exit /b 1
