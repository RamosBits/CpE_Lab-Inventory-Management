package cpe_lab_inventory;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ReturnItemDialogController {
    @FXML
    private Label titleLabel;
    @FXML
    private Label itemNameLabel;
    @FXML
    private Label itemTypeLabel;
    @FXML
    private Label quantityBorrowedLabel;
    @FXML
    private Label warningLabel;
    @FXML
    private Spinner<Integer> quantityReturningSpinner;

    private ReturnDetails returnDetails;
    private Stage dialogStage;
    private boolean submitClicked = false;

    @FXML
    public void initialize() {
        warningLabel.setText("");
    }

    public void setReturnDetails(ReturnDetails details) {
        this.returnDetails = details;
        
        itemNameLabel.setText(details.getItemName());
        itemTypeLabel.setText(details.getItemType());
        quantityBorrowedLabel.setText(String.valueOf(details.getQuantityBorrowed()));
        
        // Set up spinner based on item type (Tools and Equipment default to 1, Consumables use full quantity)
        int defaultValue = (details.getItemType().equalsIgnoreCase("Tool") || details.getItemType().equalsIgnoreCase("Equipment")) ? 1 : details.getQuantityBorrowed();
        SpinnerValueFactory<Integer> valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(
            1, details.getQuantityBorrowed(), defaultValue
        );
        quantityReturningSpinner.setValueFactory(valueFactory);
        
        // Update warning label based on quantity
        updateWarningLabel();
        
        quantityReturningSpinner.valueProperty().addListener((obs, oldVal, newVal) -> updateWarningLabel());
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public boolean isSubmitClicked() {
        return submitClicked;
    }

    public int getQuantityReturning() {
        return quantityReturningSpinner.getValue();
    }

    private void updateWarningLabel() {
        int borrowed = returnDetails.getQuantityBorrowed();
        int returning = quantityReturningSpinner.getValue();
        
        if (returning < borrowed) {
            warningLabel.setText("⚠ Partial return: " + (borrowed - returning) + " items still outstanding");
            warningLabel.setStyle("-fx-text-fill: #FF9800;");
        } else if (returning == borrowed) {
            warningLabel.setText("✓ Full return");
            warningLabel.setStyle("-fx-text-fill: #4CAF50;");
        }
    }

    @FXML
    private void handleSubmitReturn() {
        submitClicked = true;
        dialogStage.close();
    }

    @FXML
    private void handleCancel() {
        submitClicked = false;
        dialogStage.close();
    }

    public static Integer showReturnDialog(Transaction transaction, Item item) {
        try {
            // Get item type from database
            ReturnDetails details = new ReturnDetails(
                transaction.getTransactionId(),
                transaction.getItemName(),
                item.getType(),
                transaction.getQuantity(),
                0,
                transaction.getStatus()
            );

            FXMLLoader loader = new FXMLLoader(ReturnItemDialogController.class.getResource("ReturnItemDialog.fxml"));
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Process Return");
            dialogStage.initModality(Modality.APPLICATION_MODAL);
            dialogStage.setScene(new Scene(loader.load()));

            ReturnItemDialogController controller = loader.getController();
            controller.setReturnDetails(details);
            controller.setDialogStage(dialogStage);

            dialogStage.showAndWait();

            if (controller.isSubmitClicked()) {
                return controller.getQuantityReturning();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Failed to open return dialog: " + e.getMessage());
            alert.showAndWait();
        }
        return null;
    }
}
