@echo off
setlocal
cd /d "%~dp0..\.."

set APP_NAME=CpE_Lab_Inventory
set MAIN_CLASS=cpe_lab_inventory.MainApp

REM Change these two paths on the Windows deployment PC.
set JAVAFX_LIB=C:\JavaFX\javafx-sdk-25.0.2\lib
set MYSQL_JAR=C:\CpE_Lab_Inventory\lib\mysql-connector-j-8.0.33.jar

set OUT_DIR=dist\manual
set CLASSES_DIR=%OUT_DIR%\classes

if not exist "%CLASSES_DIR%\cpe_lab_inventory" mkdir "%CLASSES_DIR%\cpe_lab_inventory"
if not exist "%OUT_DIR%\lib" mkdir "%OUT_DIR%\lib"

javac ^
  --module-path "%JAVAFX_LIB%" ^
  --add-modules javafx.controls,javafx.fxml ^
  -cp "%MYSQL_JAR%" ^
  -d "%CLASSES_DIR%" ^
  src\cpe_lab_inventory\*.java

copy src\cpe_lab_inventory\*.fxml "%CLASSES_DIR%\cpe_lab_inventory\"
copy "%MYSQL_JAR%" "%OUT_DIR%\lib\"

jar --create ^
  --file "%OUT_DIR%\%APP_NAME%.jar" ^
  --manifest deploy\MANIFEST.MF ^
  -C "%CLASSES_DIR%" .

echo Built %OUT_DIR%\%APP_NAME%.jar
endlocal
