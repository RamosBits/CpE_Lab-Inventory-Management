package cpe_lab_inventory;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.collections.FXCollections;

public class StudentsController extends BaseModuleController {
    @FXML
    private TableView<Student> studentsTable;
    @FXML
    private TextField studentIdField;
    @FXML
    private TextField studentNameField;
    @FXML
    private TextField studentCourseField;
    @FXML
    private TextField studentYearField;
    @FXML
    private TextField studentContactField;
    @FXML
    private TableColumn<Student, String> studentIdColumn;
    @FXML
    private TableColumn<Student, String> studentNameColumn;
    @FXML
    private TableColumn<Student, String> studentCourseColumn;
    @FXML
    private TableColumn<Student, Integer> studentYearColumn;
    @FXML
    private TableColumn<Student, String> studentContactColumn;
    @FXML
    private TableColumn<Student, String> registeredDateColumn;
    @FXML
    private TableColumn<Student, String> actionColumn;
    @FXML
    private TextField searchField;

    private ObservableList<Student> allStudents;

    @FXML
    public void initialize() {
        setupStudentsTableColumns();
        loadStudentsTable();
    }

    private void setupStudentsTableColumns() {
        studentIdColumn.setCellValueFactory(new PropertyValueFactory<>("studentId"));
        studentNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        studentCourseColumn.setCellValueFactory(new PropertyValueFactory<>("course"));
        studentYearColumn.setCellValueFactory(new PropertyValueFactory<>("yearLevel"));
        studentContactColumn.setCellValueFactory(new PropertyValueFactory<>("contactNumber"));
        registeredDateColumn.setCellValueFactory(new PropertyValueFactory<>("registeredAt"));
        
        // Setup action column with delete button
        actionColumn.setCellFactory(param -> new TableCell<Student, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    Student student = getTableView().getItems().get(getIndex());
                    
                    HBox actionBox = new HBox(5);
                    actionBox.setAlignment(Pos.CENTER);
                    
                    Button deleteBtn = new Button("Delete");
                    deleteBtn.setStyle("-fx-padding: 5 10; -fx-background-color: #d32f2f; -fx-text-fill: white; -fx-cursor: hand; -fx-font-size: 10;");
                    deleteBtn.setOnAction(event -> handleDeleteStudent(student));
                    actionBox.getChildren().add(deleteBtn);
                    
                    setGraphic(actionBox);
                }
            }
        });
    }

    @FXML
    private void handleAddStudent() {
        String studentId = studentIdField.getText().trim();
        String name = studentNameField.getText().trim();
        String course = studentCourseField.getText().trim();
        String yearStr = studentYearField.getText().trim();
        String contact = studentContactField.getText().trim();

        if (studentId.isEmpty() || name.isEmpty() || course.isEmpty() || yearStr.isEmpty() || contact.isEmpty()) {
            showAlert("Validation Error", "All fields are required.", Alert.AlertType.WARNING);
            return;
        }

        try {
            int year = Integer.parseInt(yearStr);
            if (year < 1 || year > 4) {
                showAlert("Validation Error", "Year level must be between 1 and 4.", Alert.AlertType.WARNING);
                return;
            }

            boolean success = DatabaseManager.saveStudent(studentId, name, course, year, contact);
            if (success) {
                showAlert("Success", "Student added successfully!", Alert.AlertType.INFORMATION);
                clearStudentFields();
                loadStudentsTable();
            } else {
                showAlert("Error", "Failed to add student. Student ID may already exist.", Alert.AlertType.ERROR);
            }
        } catch (NumberFormatException e) {
            showAlert("Input Error", "Year level must be a valid number.", Alert.AlertType.ERROR);
        }
    }

    private void handleDeleteStudent(Student student) {
        Alert confirmAlert = new Alert(Alert.AlertType.CONFIRMATION);
        confirmAlert.setTitle("Confirm Delete");
        confirmAlert.setHeaderText(null);
        confirmAlert.setContentText("Delete student \"" + student.getName() + "\" (ID: " + student.getStudentId() + ")?\n(Data will be hidden but kept in database)");
        
        if (confirmAlert.showAndWait().get() == javafx.scene.control.ButtonType.OK) {
            boolean success = DatabaseManager.deleteStudent(student.getStudentId());
            if (success) {
                showAlert("Success", "Student deleted successfully!", Alert.AlertType.INFORMATION);
                loadStudentsTable();
            } else {
                showAlert("Error", "Failed to delete student.", Alert.AlertType.ERROR);
            }
        }
    }

    private void clearStudentFields() {
        studentIdField.clear();
        studentNameField.clear();
        studentCourseField.clear();
        studentYearField.clear();
        studentContactField.clear();
    }

    private void loadStudentsTable() {
        try {
            allStudents = DatabaseManager.getAllStudents();
            studentsTable.setItems(allStudents);
        } catch (Exception e) {
            showAlert("Database Error", "Failed to load students table: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleSearch() {
        String searchText = searchField.getText().toLowerCase();
        
        if (searchText.isEmpty()) {
            studentsTable.setItems(allStudents);
            return;
        }

        ObservableList<Student> filteredStudents = FXCollections.observableArrayList();
        for (Student student : allStudents) {
            if (student.getStudentId().toLowerCase().contains(searchText) ||
                student.getName().toLowerCase().contains(searchText) ||
                student.getCourse().toLowerCase().contains(searchText)) {
                filteredStudents.add(student);
            }
        }
        studentsTable.setItems(filteredStudents);
    }

    @FXML
    private void handleClearSearch() {
        searchField.clear();
        studentsTable.setItems(allStudents);
    }
}
