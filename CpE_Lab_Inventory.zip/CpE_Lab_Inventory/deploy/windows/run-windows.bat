@echo off
setlocal
cd /d "%~dp0..\.."

set JAVAFX_LIB=C:\JavaFX\javafx-sdk-25.0.2\lib
set MYSQL_JAR=dist\manual\lib\mysql-connector-j-8.0.33.jar
set APP_JAR=dist\manual\CpE_Lab_Inventory.jar

java ^
  --module-path "%JAVAFX_LIB%" ^
  --add-modules javafx.controls,javafx.fxml ^
  -cp "%APP_JAR%;%MYSQL_JAR%" ^
  cpe_lab_inventory.MainApp

endlocal
