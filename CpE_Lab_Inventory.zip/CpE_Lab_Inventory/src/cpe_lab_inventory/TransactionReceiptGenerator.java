package cpe_lab_inventory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javafx.stage.Stage;
import javafx.scene.control.Alert;

/**
 * TransactionReceiptGenerator - Generates transaction receipts as PDF files
 * Auto-saves to receipts folder and shows preview
 */
public class TransactionReceiptGenerator {
    /**
     * Generate a transaction receipt, auto-save to receipts folder, and show preview
     * @param orNumber Order/Receipt number
     * @param student Student information
     * @param items Items borrowed
     * @param encoder User who encoded the transaction
     * @return true if successful, false otherwise
     */
    public static boolean generateTransactionReceipt(int orNumber, Student student, 
                                                     List<TransactionItem> items, 
                                                     User encoder) {
        try {
            File receiptsDir = AppPaths.getReceiptsDirectory();

            // Generate filename with timestamp
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
            String timestamp = dateFormat.format(new Date());
            String fileName = String.format("Receipt_OR%d_%s.pdf", orNumber, timestamp);
            File outputFile = new File(receiptsDir, fileName);
            
            // Generate receipt content
            String receiptContent = generateReceiptContent(orNumber, student, items, encoder);
            
            // Create PDF file
            createPDFReceipt(outputFile, receiptContent, orNumber);
            
            System.out.println("Receipt auto-saved to: " + outputFile.getAbsolutePath());
            
            // Show preview in alert
            showReceiptPreview(receiptContent, orNumber);
            
            return true;
            
        } catch (IOException e) {
            e.printStackTrace();
            showErrorAlert("Error generating receipt: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Create PDF receipt file
     */
    private static void createPDFReceipt(File outputFile, String content, int orNumber) throws IOException {
        // Create a simple PDF with the receipt content
        try (FileOutputStream fos = new FileOutputStream(outputFile)) {
            byte[] contentBytes = content.getBytes();
            
            // PDF header
            fos.write("%PDF-1.4\n".getBytes());
            
            // Object 1: Catalog
            fos.write("1 0 obj\n".getBytes());
            fos.write("<< /Type /Catalog /Pages 2 0 R >>\n".getBytes());
            fos.write("endobj\n".getBytes());
            
            // Object 2: Pages
            fos.write("2 0 obj\n".getBytes());
            fos.write("<< /Type /Pages /Kids [3 0 R] /Count 1 >>\n".getBytes());
            fos.write("endobj\n".getBytes());
            
            // Object 3: Page
            fos.write("3 0 obj\n".getBytes());
            fos.write("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 << /Type /Font /Subtype /Type1 /BaseFont /Courier >> >> >> >>\n".getBytes());
            fos.write("endobj\n".getBytes());
            
            // Object 4: Content Stream
            fos.write("4 0 obj\n".getBytes());
            fos.write("<< /Length ".getBytes());
            fos.write(String.valueOf(contentBytes.length + 200).getBytes());
            fos.write(" >>\n".getBytes());
            fos.write("stream\n".getBytes());
            fos.write("BT\n".getBytes());
            fos.write("/F1 10 Tf\n".getBytes());
            fos.write("50 750 Td\n".getBytes());
            
            // Write content line by line
            String[] lines = content.split("\n");
            for (String line : lines) {
                fos.write("(".getBytes());
                fos.write(escapePDFString(line).getBytes());
                fos.write(") Tj\n".getBytes());
                fos.write("0 -12 Td\n".getBytes());
            }
            
            fos.write("ET\n".getBytes());
            fos.write("endstream\n".getBytes());
            fos.write("endobj\n".getBytes());
            
            // xref and trailer
            long xrefPos = outputFile.length();
            fos.write("xref\n".getBytes());
            fos.write("0 5\n".getBytes());
            fos.write("0000000000 65535 f \n".getBytes());
            fos.write("0000000010 00000 n \n".getBytes());
            fos.write("0000000059 00000 n \n".getBytes());
            fos.write("0000000118 00000 n \n".getBytes());
            fos.write("0000000316 00000 n \n".getBytes());
            
            fos.write("trailer\n".getBytes());
            fos.write("<< /Size 5 /Root 1 0 R >>\n".getBytes());
            fos.write("startxref\n".getBytes());
            fos.write(String.valueOf(xrefPos + 100).getBytes());
            fos.write("\n%%EOF\n".getBytes());
        }
    }
    
    private static String escapePDFString(String str) {
        return str.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)");
    }
    
    /**
     * Show receipt preview in a larger window
     */
    private static void showReceiptPreview(String receiptContent, int orNumber) {
        javafx.scene.control.TextArea textArea = new javafx.scene.control.TextArea();
        textArea.setText(receiptContent);
        textArea.setWrapText(true);
        textArea.setEditable(false);
        textArea.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 11;");
        
        javafx.scene.layout.BorderPane root = new javafx.scene.layout.BorderPane();
        root.setCenter(textArea);
        
        javafx.scene.control.Button closeButton = new javafx.scene.control.Button("Close");
        closeButton.setStyle("-fx-padding: 10; -fx-font-size: 12;");
        javafx.scene.layout.HBox buttonBox = new javafx.scene.layout.HBox();
        buttonBox.setStyle("-fx-padding: 10; -fx-alignment: CENTER;");
        buttonBox.getChildren().add(closeButton);
        root.setBottom(buttonBox);
        
        javafx.scene.Scene scene = new javafx.scene.Scene(root, 700, 800);
        Stage previewStage = new Stage();
        previewStage.setTitle("Receipt Preview - OR #" + orNumber);
        previewStage.setScene(scene);
        
        closeButton.setOnAction(e -> previewStage.close());
        
        previewStage.showAndWait();
    }
    
    private static void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Receipt Generation Failed");
        alert.setContentText(message);
        alert.showAndWait();
    }
    
    /**
     * Generate the formatted receipt content
     */
    private static String generateReceiptContent(int orNumber, Student student, 
                                                  List<TransactionItem> items, User encoder) {
        StringBuilder receipt = new StringBuilder();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String timestamp = dateFormat.format(new Date());
        
        // Header
        addCenteredLine(receipt, "╔═════════════════════════════════════════════════════════╗");
        addCenteredLine(receipt, "║       CPE LAB INVENTORY SYSTEM - TRANSACTION RECEIPT     ║");
        addCenteredLine(receipt, "╚═════════════════════════════════════════════════════════╝");
        receipt.append("\n");
        
        // Transaction Details
        addField(receipt, "OR Number", String.valueOf(orNumber));
        addField(receipt, "Date & Time", timestamp);
        receipt.append("\n");
        
        addLine(receipt, "─────────────────────────────────────────────────────────");
        
        // Student Information
        addSectionHeader(receipt, "STUDENT INFORMATION");
        addField(receipt, "Student ID", student.getStudentId());
        addField(receipt, "Name", student.getName());
        addField(receipt, "Course", student.getCourse());
        addField(receipt, "Year Level", String.valueOf(student.getYearLevel()));
        addField(receipt, "Contact", student.getContactNumber());
        receipt.append("\n");
        
        addLine(receipt, "─────────────────────────────────────────────────────────");
        
        // Items
        addSectionHeader(receipt, "ITEMS BORROWED");
        receipt.append("No. | Item Name                        | ID    | Qty\n");
        addLine(receipt, "─────────────────────────────────────────────────────────");
        
        int counter = 1;
        for (TransactionItem item : items) {
            String itemLine = String.format("%3d | %-32s | %5s | %3d",
                counter++,
                truncate(item.getItemName(), 32),
                item.getItemId(),
                item.getQuantity()
            );
            receipt.append(itemLine).append("\n");
        }
        receipt.append("\n");
        
        addLine(receipt, "─────────────────────────────────────────────────────────");
        
        // Encoder and Signature Section
        addSectionHeader(receipt, "AUTHORIZED BY");
        addField(receipt, "Issued By", encoder.getfName() + " " + encoder.getlName());
        addField(receipt, "Position", encoder.getRoles());
        receipt.append("\n");
        
        receipt.append("Encoder Signature: ________________________     Date: ____________\n");
        receipt.append("Student Signature: ________________________     Date: ____________\n");
        receipt.append("\n");
        
        addLine(receipt, "─────────────────────────────────────────────────────────");
        addCenteredLine(receipt, "Thank you for using CPE Lab Inventory System");
        addCenteredLine(receipt, "Please return all items in good condition");
        receipt.append("\n");
        
        return receipt.toString();
    }
    
    private static void addField(StringBuilder sb, String label, String value) {
        sb.append(String.format("%-20s : %s%n", label, value));
    }
    
    private static void addSectionHeader(StringBuilder sb, String header) {
        sb.append(String.format(">>> %s <<<\n", header));
    }
    
    private static void addLine(StringBuilder sb, String line) {
        sb.append(line).append("\n");
    }
    
    private static void addCenteredLine(StringBuilder sb, String line) {
        sb.append(String.format("%63s%n", line));
    }
    
    private static String truncate(String str, int length) {
        if (str.length() <= length) {
            return str;
        }
        return str.substring(0, length - 3) + "...";
    }
}
