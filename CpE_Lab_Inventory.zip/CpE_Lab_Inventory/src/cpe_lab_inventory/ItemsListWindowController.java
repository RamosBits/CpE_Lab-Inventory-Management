package cpe_lab_inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ItemsListWindowController {
    @FXML
    private TableView<Item> itemsTable;
    @FXML
    private TextField searchField;
    @FXML
    private TableColumn<Item, Integer> itemIdColumn;
    @FXML
    private TableColumn<Item, String> itemNameColumn;
    @FXML
    private TableColumn<Item, String> typeColumn;
    @FXML
    private TableColumn<Item, Integer> totalStockColumn;
    @FXML
    private TableColumn<Item, Integer> currentStockColumn;
    @FXML
    private TableColumn<Item, String> timestampColumn;

    private ObservableList<Item> allItems;

    @FXML
    public void initialize() {
        setupTableColumns();
        loadItems();
    }

    private void setupTableColumns() {
        itemIdColumn.setCellValueFactory(new PropertyValueFactory<>("itemId"));
        itemNameColumn.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        totalStockColumn.setCellValueFactory(new PropertyValueFactory<>("totalStock"));
        currentStockColumn.setCellValueFactory(new PropertyValueFactory<>("currentStock"));
        timestampColumn.setCellValueFactory(new PropertyValueFactory<>("timestamp"));
    }

    @FXML
    private void handleSearch() {
        String searchText = searchField.getText().toLowerCase();
        
        if (searchText.isEmpty()) {
            itemsTable.setItems(allItems);
            return;
        }

        ObservableList<Item> filteredItems = FXCollections.observableArrayList();
        for (Item item : allItems) {
            if (item.getItemName().toLowerCase().contains(searchText) ||
                item.getType().toLowerCase().contains(searchText)) {
                filteredItems.add(item);
            }
        }
        itemsTable.setItems(filteredItems);
    }

    @FXML
    private void handleRefresh() {
        searchField.clear();
        loadItems();
    }

    private void loadItems() {
        try {
            allItems = DatabaseManager.getAllItems();
            itemsTable.setItems(allItems);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void showItemsListWindow() {
        try {
            FXMLLoader loader = new FXMLLoader(ItemsListWindowController.class.getResource("ItemsListWindow.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Items Inventory Reference");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.WINDOW_MODAL);
            stage.setResizable(true);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
