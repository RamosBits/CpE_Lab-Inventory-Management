package cpe_lab_inventory;

public class ReturnDetails {
    private int transactionId;
    private String itemName;
    private String itemType;
    private int quantityBorrowed;
    private int quantityReturned;
    private String status;

    public ReturnDetails() {
        this.transactionId = 0;
        this.itemName = "";
        this.itemType = "";
        this.quantityBorrowed = 0;
        this.quantityReturned = 0;
        this.status = "";
    }

    public ReturnDetails(int transactionId, String itemName, String itemType, int quantityBorrowed, int quantityReturned, String status) {
        this.transactionId = transactionId;
        this.itemName = itemName;
        this.itemType = itemType;
        this.quantityBorrowed = quantityBorrowed;
        this.quantityReturned = quantityReturned;
        this.status = status;
    }

    public int getTransactionId() { return transactionId; }
    public void setTransactionId(int id) { this.transactionId = id; }
    public String getItemName() { return itemName; }
    public void setItemName(String name) { this.itemName = name; }
    public String getItemType() { return itemType; }
    public void setItemType(String type) { this.itemType = type; }
    public int getQuantityBorrowed() { return quantityBorrowed; }
    public void setQuantityBorrowed(int qty) { this.quantityBorrowed = qty; }
    public int getQuantityReturned() { return quantityReturned; }
    public void setQuantityReturned(int qty) { this.quantityReturned = qty; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
