#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

APP_JAR="dist/manual/CpE_Lab_Inventory.jar"
JAVAFX_LIB="${JAVAFX_LIB:-/home/caryd/Downloads/Netbeans/openjfx-25.0.2_linux-x64_bin-sdk/javafx-sdk-25.0.2/lib}"
MYSQL_JAR="${MYSQL_JAR:-/home/caryd/Documents/mysql-connector-j-8.0.33/mysql-connector-j-8.0.33.jar}"

java \
  --module-path "$JAVAFX_LIB" \
  --add-modules javafx.controls,javafx.fxml \
  -cp "$APP_JAR:$MYSQL_JAR" \
  cpe_lab_inventory.MainApp
