package cpe_lab_inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ItemSelectionDialogController {
    @FXML
    private TableView<Item> itemsTable;
    @FXML
    private TextField searchField;
    @FXML
    private TableColumn<Item, Integer> itemIdColumn;
    @FXML
    private TableColumn<Item, String> itemNameColumn;
    @FXML
    private TableColumn<Item, String> typeColumn;
    @FXML
    private TableColumn<Item, Integer> totalStockColumn;
    @FXML
    private TableColumn<Item, Integer> currentStockColumn;
    @FXML
    private TableColumn<Item, String> availabilityColumn;

    private ObservableList<Item> allItems;
    private Item selectedItem;
    private Stage dialogStage;

    @FXML
    public void initialize() {
        setupTableColumns();
        loadItems();
    }

    private void setupTableColumns() {
        itemIdColumn.setCellValueFactory(new PropertyValueFactory<>("itemId"));
        itemNameColumn.setCellValueFactory(new PropertyValueFactory<>("itemName"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        totalStockColumn.setCellValueFactory(new PropertyValueFactory<>("totalStock"));
        currentStockColumn.setCellValueFactory(new PropertyValueFactory<>("currentStock"));
        
        // Custom column for availability status
        availabilityColumn.setCellValueFactory(cellData -> {
            int currentStock = cellData.getValue().getCurrentStock();
            String status = currentStock > 0 ? "Available (" + currentStock + ")" : "Out of Stock";
            return new javafx.beans.property.SimpleStringProperty(status);
        });
    }

    @FXML
    private void handleSearch() {
        String searchText = searchField.getText().toLowerCase();
        
        if (searchText.isEmpty()) {
            itemsTable.setItems(allItems);
            return;
        }

        ObservableList<Item> filteredItems = FXCollections.observableArrayList();
        for (Item item : allItems) {
            if (item.getItemName().toLowerCase().contains(searchText) ||
                item.getType().toLowerCase().contains(searchText)) {
                filteredItems.add(item);
            }
        }
        itemsTable.setItems(filteredItems);
    }

    @FXML
    private void handleSelect() {
        selectedItem = itemsTable.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No Selection");
            alert.setHeaderText(null);
            alert.setContentText("Please select an item.");
            alert.showAndWait();
            return;
        }
        dialogStage.close();
    }

    @FXML
    private void handleCancel() {
        selectedItem = null;
        dialogStage.close();
    }

    private void loadItems() {
        try {
            allItems = DatabaseManager.getAllItems();
            itemsTable.setItems(allItems);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public Item getSelectedItem() {
        return selectedItem;
    }

    public static Item showItemSelectionDialog() {
        try {
            FXMLLoader loader = new FXMLLoader(ItemSelectionDialogController.class.getResource("ItemSelectionDialog.fxml"));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle("Select Item");
            stage.setScene(new Scene(root));
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setResizable(true);

            ItemSelectionDialogController controller = loader.getController();
            controller.setDialogStage(stage);

            stage.showAndWait();
            return controller.getSelectedItem();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
