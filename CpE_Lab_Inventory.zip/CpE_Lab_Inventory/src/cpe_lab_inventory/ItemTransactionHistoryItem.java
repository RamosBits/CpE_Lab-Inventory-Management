package cpe_lab_inventory;

import javafx.beans.property.*;

public class ItemTransactionHistoryItem {
    private final IntegerProperty orNumber;
    private final StringProperty studentId;
    private final StringProperty studentName;
    private final IntegerProperty quantity;
    private final StringProperty status;
    private final StringProperty borrowDate;
    private final StringProperty returnDate;
    private final StringProperty encoderName;

    public ItemTransactionHistoryItem(int orNumber, String studentId, String studentName, 
                                      int quantity, String status, String borrowDate, 
                                      String returnDate, String encoderName) {
        this.orNumber = new SimpleIntegerProperty(orNumber);
        this.studentId = new SimpleStringProperty(studentId);
        this.studentName = new SimpleStringProperty(studentName);
        this.quantity = new SimpleIntegerProperty(quantity);
        this.status = new SimpleStringProperty(status);
        this.borrowDate = new SimpleStringProperty(borrowDate);
        this.returnDate = new SimpleStringProperty(returnDate != null ? returnDate : "Not Returned");
        this.encoderName = new SimpleStringProperty(encoderName);
    }

    public int getOrNumber() { return orNumber.get(); }
    public IntegerProperty orNumberProperty() { return orNumber; }
    
    public String getStudentId() { return studentId.get(); }
    public StringProperty studentIdProperty() { return studentId; }
    
    public String getStudentName() { return studentName.get(); }
    public StringProperty studentNameProperty() { return studentName; }
    
    public int getQuantity() { return quantity.get(); }
    public IntegerProperty quantityProperty() { return quantity; }
    
    public String getStatus() { return status.get(); }
    public StringProperty statusProperty() { return status; }
    
    public String getBorrowDate() { return borrowDate.get(); }
    public StringProperty borrowDateProperty() { return borrowDate; }
    
    public String getReturnDate() { return returnDate.get(); }
    public StringProperty returnDateProperty() { return returnDate; }
    
    public String getEncoderName() { return encoderName.get(); }
    public StringProperty encoderNameProperty() { return encoderName; }
}
