-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: cpelab_db
-- ------------------------------------------------------
-- Server version	8.0.45-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `calibration_history`
--

DROP TABLE IF EXISTS `calibration_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calibration_history` (
  `calibration_id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `status` varchar(40) NOT NULL,
  `notes` text,
  `checked_by` int DEFAULT NULL,
  `checked_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint DEFAULT '0',
  `unit_id` int DEFAULT NULL,
  PRIMARY KEY (`calibration_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calibration_history`
--

LOCK TABLES `calibration_history` WRITE;
/*!40000 ALTER TABLE `calibration_history` DISABLE KEYS */;
INSERT INTO `calibration_history` VALUES (1,2,'Functional','',1,'2026-05-25 10:58:55',0,NULL);
/*!40000 ALTER TABLE `calibration_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_units`
--

DROP TABLE IF EXISTS `item_units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_units` (
  `unit_id` int NOT NULL AUTO_INCREMENT,
  `item_id` int NOT NULL,
  `unit_code` varchar(50) NOT NULL,
  `status` varchar(30) DEFAULT 'Available',
  `is_deleted` tinyint DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `borrowed_or_num` int DEFAULT NULL,
  PRIMARY KEY (`unit_id`),
  UNIQUE KEY `unit_code` (`unit_code`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_units`
--

LOCK TABLES `item_units` WRITE;
/*!40000 ALTER TABLE `item_units` DISABLE KEYS */;
INSERT INTO `item_units` VALUES (1,2,'2-001','Available',0,'2026-05-13 12:24:53',NULL),(2,2,'2-002','Available',0,'2026-05-13 12:24:54',NULL),(3,2,'2-003','Available',0,'2026-05-13 12:24:54',NULL),(4,2,'2-004','Available',0,'2026-05-13 12:24:54',NULL),(5,2,'2-005','Available',0,'2026-05-13 12:24:54',NULL),(6,5,'5-001','Available',0,'2026-05-13 12:24:59',NULL),(7,5,'5-002','Available',0,'2026-05-13 12:24:59',NULL),(8,5,'5-003','Available',0,'2026-05-13 12:24:59',NULL),(9,5,'5-004','Available',0,'2026-05-13 12:24:59',NULL),(10,5,'5-005','Available',0,'2026-05-13 12:24:59',NULL),(11,5,'5-006','Available',0,'2026-05-13 12:25:00',NULL),(12,5,'5-007','Available',0,'2026-05-13 12:25:00',NULL),(13,5,'5-008','Available',0,'2026-05-13 12:25:00',NULL),(14,5,'5-009','Available',0,'2026-05-13 12:25:00',NULL),(15,5,'5-010','Available',0,'2026-05-13 12:25:01',NULL),(16,5,'5-011','Available',0,'2026-05-13 12:25:01',NULL),(17,5,'5-012','Available',0,'2026-05-13 12:25:01',NULL),(18,5,'5-013','Available',0,'2026-05-13 12:25:01',NULL),(19,5,'5-014','Available',0,'2026-05-13 12:25:01',NULL),(20,5,'5-015','Available',0,'2026-05-13 12:25:01',NULL),(21,5,'5-016','Available',0,'2026-05-13 12:25:01',NULL),(22,5,'5-017','Available',0,'2026-05-13 12:25:01',NULL),(23,5,'5-018','Available',0,'2026-05-13 12:25:01',NULL),(24,5,'5-019','Available',0,'2026-05-13 12:25:01',NULL),(25,5,'5-020','Available',0,'2026-05-13 12:25:02',NULL),(26,5,'5-021','Available',0,'2026-05-13 12:25:02',NULL),(27,5,'5-022','Available',0,'2026-05-13 12:25:02',NULL),(28,5,'5-023','Available',0,'2026-05-13 12:25:02',NULL),(29,5,'5-024','Available',0,'2026-05-13 12:25:02',NULL),(30,5,'5-025','Available',0,'2026-05-13 12:25:02',NULL),(31,5,'5-026','Available',0,'2026-05-13 12:25:02',NULL),(32,5,'5-027','Available',0,'2026-05-13 12:25:02',NULL),(33,5,'5-028','Available',0,'2026-05-13 12:25:02',NULL),(34,5,'5-029','Available',0,'2026-05-13 12:25:02',NULL),(35,5,'5-030','Available',0,'2026-05-13 12:25:03',NULL),(36,5,'5-031','Available',0,'2026-05-13 12:25:03',NULL),(37,5,'5-032','Available',0,'2026-05-13 12:25:03',NULL),(38,5,'5-033','Available',0,'2026-05-13 12:25:03',NULL),(39,5,'5-034','Available',0,'2026-05-13 12:25:03',NULL),(40,5,'5-035','Available',0,'2026-05-13 12:25:03',NULL),(41,5,'5-036','Available',0,'2026-05-13 12:25:03',NULL),(42,5,'5-037','Available',0,'2026-05-13 12:25:03',NULL),(43,5,'5-038','Available',0,'2026-05-13 12:25:04',NULL),(44,5,'5-039','Available',0,'2026-05-13 12:25:04',NULL),(45,5,'5-040','Available',0,'2026-05-13 12:25:04',NULL),(46,5,'5-041','Available',0,'2026-05-13 12:25:04',NULL),(47,5,'5-042','Available',0,'2026-05-13 12:25:04',NULL),(48,5,'5-043','Available',0,'2026-05-13 12:25:04',NULL),(49,5,'5-044','Available',0,'2026-05-13 12:25:05',NULL),(50,5,'5-045','Available',0,'2026-05-13 12:25:05',NULL),(51,5,'5-046','Available',0,'2026-05-13 12:25:05',NULL),(52,5,'5-047','Available',0,'2026-05-13 12:25:05',NULL),(53,5,'5-048','Available',0,'2026-05-13 12:25:05',NULL),(54,5,'5-049','Available',0,'2026-05-13 12:25:05',NULL),(55,5,'5-050','Available',0,'2026-05-13 12:25:05',NULL),(56,8,'8-001','Available',0,'2026-05-13 12:25:14',NULL),(57,8,'8-002','Available',0,'2026-05-13 12:25:14',NULL),(58,8,'8-003','Available',0,'2026-05-13 12:25:14',NULL),(59,8,'8-004','Available',0,'2026-05-13 12:25:14',NULL),(60,8,'8-005','Available',0,'2026-05-13 12:25:14',NULL),(61,9,'9-001','Available',0,'2026-05-13 12:27:47',NULL),(62,9,'9-002','Available',0,'2026-05-13 12:27:47',NULL),(63,9,'9-003','Borrowed',0,'2026-05-13 12:36:04',14);
/*!40000 ALTER TABLE `item_units` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `item_id` int unsigned NOT NULL AUTO_INCREMENT,
  `item_name` varchar(100) NOT NULL,
  `type` enum('Tool','Consumable','Equipment') DEFAULT NULL,
  `total_stock` int unsigned NOT NULL,
  `current_stock` int unsigned NOT NULL,
  `users_user_id` int NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  `is_deleted` int DEFAULT '0',
  PRIMARY KEY (`item_id`),
  KEY `fk_items_users1_idx` (`users_user_id`),
  CONSTRAINT `fk_items_users1` FOREIGN KEY (`users_user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (1,'Soldering Lead Wire','Consumable',10,10,1,NULL,0),(2,'Plier','Tool',5,5,1,NULL,0),(3,'Power Supply','Tool',1,1,1,'2026-03-19 12:14:26',1),(5,'Male to Male Arduino Wire','Tool',50,50,1,'2026-03-25 10:23:37',0),(6,'random','Tool',5,5,1,'2026-04-03 14:49:06',1),(7,'Soldering Iron','Tool',5,5,1,'2026-04-20 12:51:53',0),(8,'Multimeter','Equipment',5,5,1,'2026-04-25 11:15:19',0),(9,'Power Supply','Equipment',3,3,1,'2026-05-04 10:28:45',0);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `student_id` varchar(20) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `course` varchar(50) DEFAULT NULL,
  `year_level` int DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `registered_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` int DEFAULT '0',
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES ('1231','Wgat','ASd',1,'123123123','2026-03-19 04:11:09',0),('2016-0162-7','Jana Alyxa T. Estelloso','CpE',4,'099999999','2026-03-25 02:24:31',0),('2019-0029-1','Augustien Caryd A. Ramos','CpE',4,'09917347811','2026-03-12 06:10:03',0),('2019-0188-7','Leah Angela B. Hermita','CpE',4,'090129033','2026-05-04 02:31:41',0),('2022-0058-2','Khylle Noelle L. Reyes','CpE',4,'0909090909','2026-04-20 04:53:16',0);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `transaction_id` int NOT NULL AUTO_INCREMENT,
  `or_num` int NOT NULL,
  `borrower_id` int DEFAULT NULL,
  `student_id` varchar(20) DEFAULT NULL,
  `item_id` int unsigned NOT NULL,
  `encoder_id` int NOT NULL,
  `quantity_taken` int unsigned NOT NULL,
  `quantity_returned` int unsigned DEFAULT '0',
  `borrow_date` datetime NOT NULL,
  `return_date` datetime DEFAULT NULL,
  `admin_note` varchar(255) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT '0',
  `status` enum('Borrowed','Partially Returned','Returned','Consumed','Overdue') DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `fk_transactions_users_idx` (`borrower_id`),
  KEY `fk_transactions_users1_idx` (`encoder_id`),
  KEY `fk_transactions_items1_idx` (`item_id`),
  KEY `fk_transactions_students` (`student_id`),
  CONSTRAINT `fk_transactions_items1` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`),
  CONSTRAINT `fk_transactions_students` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `fk_transactions_users` FOREIGN KEY (`borrower_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `fk_transactions_users1` FOREIGN KEY (`encoder_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (11,1,NULL,'2019-0029-1',5,1,0,5,'2026-03-31 14:34:22','2026-04-03 14:48:34',NULL,1,'Returned','2026-03-31 14:34:22'),(12,2,NULL,'2019-0029-1',1,1,0,3,'2026-04-03 15:02:45','2026-04-03 15:03:46',NULL,0,'Returned','2026-04-03 15:02:45'),(13,2,NULL,'2019-0029-1',2,1,1,0,'2026-04-03 15:02:45',NULL,NULL,1,'Borrowed','2026-04-03 15:02:45'),(14,3,NULL,'2016-0162-7',1,1,3,0,'2026-04-03 15:08:08',NULL,NULL,1,'Borrowed','2026-04-03 15:08:08'),(15,4,NULL,'2016-0162-7',5,1,0,2,'2026-04-14 13:47:23','2026-04-14 13:47:53',NULL,0,'Returned','2026-04-14 13:47:23'),(16,5,NULL,'2016-0162-7',5,1,0,5,'2026-04-14 14:19:54','2026-04-27 11:24:33',NULL,0,'Returned','2026-04-14 14:19:54'),(17,6,NULL,'2019-0029-1',1,1,0,5,'2026-04-19 12:36:27','2026-04-19 12:37:52',NULL,0,'Returned','2026-04-19 12:36:27'),(18,7,NULL,'2022-0058-2',7,1,0,1,'2026-04-20 12:56:08','2026-04-20 12:58:37',NULL,0,'Returned','2026-04-20 12:56:08'),(19,7,NULL,'2022-0058-2',2,1,0,1,'2026-04-20 12:56:08','2026-04-20 13:00:00',NULL,0,'Returned','2026-04-20 12:56:08'),(20,7,NULL,'2022-0058-2',1,1,0,3,'2026-04-20 12:56:08','2026-04-20 12:59:46',NULL,0,'Returned','2026-04-20 12:56:08'),(21,8,NULL,'2022-0058-2',8,1,0,1,'2026-04-25 11:15:40','2026-04-25 11:15:54',NULL,0,'Returned','2026-04-25 11:15:40'),(22,9,NULL,'2016-0162-7',8,1,0,1,'2026-04-25 11:21:36','2026-04-25 11:22:21',NULL,0,'Returned','2026-04-25 11:21:36'),(23,10,NULL,'2019-0029-1',8,2,0,1,'2026-04-27 13:37:20','2026-04-27 13:38:13',NULL,0,'Returned','2026-04-27 13:37:20'),(24,10,NULL,'2019-0029-1',7,2,0,1,'2026-04-27 13:37:20','2026-04-27 13:38:13',NULL,0,'Returned','2026-04-27 13:37:20'),(25,10,NULL,'2019-0029-1',1,2,0,1,'2026-04-27 13:37:21','2026-04-27 13:38:36',NULL,0,'Returned','2026-04-27 13:37:21'),(26,11,NULL,'2019-0188-7',9,1,0,1,'2026-05-04 10:33:21','2026-05-04 10:35:21',NULL,0,'Returned','2026-05-04 10:33:21'),(27,11,NULL,'2019-0188-7',8,1,0,1,'2026-05-04 10:33:21','2026-05-04 10:35:21',NULL,0,'Returned','2026-05-04 10:33:21'),(28,11,NULL,'2019-0188-7',5,1,0,2,'2026-05-04 10:33:21','2026-05-04 11:16:29',NULL,0,'Returned','2026-05-04 10:33:21'),(29,12,NULL,'2019-0188-7',9,1,0,1,'2026-05-11 11:20:50','2026-05-11 11:20:58',NULL,0,'Returned','2026-05-11 11:20:50'),(30,13,NULL,'2016-0162-7',9,1,0,1,'2026-05-11 12:22:45','2026-05-11 12:22:52',NULL,0,'Returned','2026-05-11 12:22:45'),(31,14,NULL,'2019-0029-1',9,1,0,1,'2026-05-13 12:36:29','2026-05-21 15:00:51',NULL,0,'Returned','2026-05-13 12:36:29');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `l_name` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `year_level` int NOT NULL,
  `roles` enum('Student Assistant','Borrower') NOT NULL,
  `course` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`,`roles`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Ramos','Augie',4,'Student Assistant','Computer Engineering','Frost','123',NULL),(2,'Encallado','Shaira',4,'Student Assistant','CpE','Shaishai','pass123','2026-04-27 12:43:46');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-01 12:02:17
