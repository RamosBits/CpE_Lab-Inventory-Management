package cpe_lab_inventory;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

public class CalibrationHistoryDialogController {
    @FXML
    private Label itemLabel;
    @FXML
    private ComboBox<ItemUnit> unitCombo;
    @FXML
    private ComboBox<String> statusCombo;
    @FXML
    private TextArea notesArea;
    @FXML
    private TableView<CalibrationRecord> historyTable;
    @FXML
    private TableColumn<CalibrationRecord, String> unitColumn;
    @FXML
    private TableColumn<CalibrationRecord, String> dateColumn;
    @FXML
    private TableColumn<CalibrationRecord, String> statusColumn;
    @FXML
    private TableColumn<CalibrationRecord, String> notesColumn;
    @FXML
    private TableColumn<CalibrationRecord, String> checkedByColumn;

    private Item item;
    private User user;
    private Stage dialogStage;

    @FXML
    public void initialize() {
        statusCombo.setItems(FXCollections.observableArrayList(
            "Functional",
            "Not Functioning"
        ));

        unitColumn.setCellValueFactory(new PropertyValueFactory<>("unitCode"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("checkedAt"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        notesColumn.setCellValueFactory(new PropertyValueFactory<>("notes"));
        checkedByColumn.setCellValueFactory(new PropertyValueFactory<>("checkedBy"));
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public void setContext(Item item, User user) {
        this.item = item;
        this.user = user;
        itemLabel.setText(item.getItemName() + " (Item ID: " + item.getItemId() + ")");

        DatabaseManager.ensureItemUnits(item);
        ObservableList<ItemUnit> units = DatabaseManager.getItemUnits(item.getItemId());
        unitCombo.setItems(units);
        unitCombo.setOnAction(event -> loadHistory());

        if (!units.isEmpty()) {
            unitCombo.setValue(units.get(0));
        }
    }

    @FXML
    private void handleAddRecord() {
        String status = statusCombo.getValue();
        String notes = notesArea.getText().trim();
        ItemUnit selectedUnit = unitCombo.getValue();

        if (selectedUnit == null) {
            showAlert("Validation Error", "Please choose a unit code.", Alert.AlertType.WARNING);
            return;
        }

        if (status == null) {
            showAlert("Validation Error", "Please choose a status.", Alert.AlertType.WARNING);
            return;
        }

        boolean success = DatabaseManager.addCalibrationRecord(
            item.getItemId(),
            selectedUnit.getUnitId(),
            status,
            notes,
            user != null ? user.getUserId() : 0
        );

        if (success) {
            statusCombo.setValue(null);
            notesArea.clear();
            loadHistory();
        } else {
            showAlert("Error", "Failed to add calibration record.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void handleClose() {
        dialogStage.close();
    }

    private void loadHistory() {
        ItemUnit selectedUnit = unitCombo.getValue();
        if (selectedUnit == null) {
            historyTable.getItems().clear();
            return;
        }

        ObservableList<CalibrationRecord> records =
            DatabaseManager.getCalibrationHistory(
                item.getItemId(),
                selectedUnit.getUnitId()
            );
        historyTable.setItems(records);
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void show(Window owner, Item item, User user) {
        if (!DatabaseManager.isUnitTrackedType(item.getType())) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Not Applicable");
            alert.setHeaderText(null);
            alert.setContentText("Calibration history applies to equipment and tools only.");
            alert.showAndWait();
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader(
                CalibrationHistoryDialogController.class.getResource(
                    "CalibrationHistoryDialog.fxml"
                )
            );
            Stage stage = new Stage();
            stage.setTitle("Calibration History");
            stage.initOwner(owner);
            stage.initModality(Modality.WINDOW_MODAL);
            stage.setScene(new Scene(loader.load()));

            CalibrationHistoryDialogController controller = loader.getController();
            controller.setDialogStage(stage);
            controller.setContext(item, user);

            stage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
