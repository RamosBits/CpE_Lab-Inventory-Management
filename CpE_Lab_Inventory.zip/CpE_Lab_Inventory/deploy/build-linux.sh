#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

APP_NAME="CpE_Lab_Inventory"
MAIN_CLASS="cpe_lab_inventory.MainApp"
JAVAFX_LIB="${JAVAFX_LIB:-/home/caryd/Downloads/Netbeans/openjfx-25.0.2_linux-x64_bin-sdk/javafx-sdk-25.0.2/lib}"
MYSQL_JAR="${MYSQL_JAR:-/home/caryd/Documents/mysql-connector-j-8.0.33/mysql-connector-j-8.0.33.jar}"
OUT_DIR="dist/manual"
CLASSES_DIR="$OUT_DIR/classes"

mkdir -p "$CLASSES_DIR/cpe_lab_inventory" "$OUT_DIR/lib"

javac \
  --module-path "$JAVAFX_LIB" \
  --add-modules javafx.controls,javafx.fxml \
  -cp "$MYSQL_JAR" \
  -d "$CLASSES_DIR" \
  src/cpe_lab_inventory/*.java

cp src/cpe_lab_inventory/*.fxml "$CLASSES_DIR/cpe_lab_inventory/"
cp "$MYSQL_JAR" "$OUT_DIR/lib/"

jar --create \
  --file "$OUT_DIR/$APP_NAME.jar" \
  --manifest deploy/MANIFEST.MF \
  -C "$CLASSES_DIR" .

echo "Built $OUT_DIR/$APP_NAME.jar"
echo "Run with: deploy/run-linux.sh"
