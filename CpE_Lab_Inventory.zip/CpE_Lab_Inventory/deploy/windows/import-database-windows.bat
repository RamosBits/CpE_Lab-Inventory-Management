@echo off
setlocal
cd /d "%~dp0..\.."

set DB_NAME=cpelab_db
set DB_USER=root
set DB_PASS=root
set SQL_FILE=database-backup\cpelab_db.sql

mysql -u %DB_USER% -p%DB_PASS% -e "CREATE DATABASE IF NOT EXISTS %DB_NAME%;"
mysql -u %DB_USER% -p%DB_PASS% %DB_NAME% < "%SQL_FILE%"

echo Imported %SQL_FILE% into %DB_NAME%
endlocal
