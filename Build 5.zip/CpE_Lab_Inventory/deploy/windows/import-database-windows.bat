@echo off
setlocal
cd /d "%~dp0..\.."

set DB_NAME=cpelab_db
set DB_USER=root
set DB_PASS=root
set SQL_FILE=database-backup\cpelab_db.sql
set MYSQL_EXE=mysql
set MYSQL_FOUND=

where mysql >nul 2>nul
if not errorlevel 1 set MYSQL_FOUND=1

if not defined MYSQL_FOUND (
  for /d %%M in ("C:\Program Files\MySQL\MySQL Server *") do (
    if exist "%%~fM\bin\mysql.exe" (
      set MYSQL_EXE=%%~fM\bin\mysql.exe
      set MYSQL_FOUND=1
    )
  )
)

if not defined MYSQL_FOUND (
  for /d %%M in ("C:\Program Files (x86)\MySQL\MySQL Server *") do (
    if exist "%%~fM\bin\mysql.exe" (
      set MYSQL_EXE=%%~fM\bin\mysql.exe
      set MYSQL_FOUND=1
    )
  )
)

if not defined MYSQL_FOUND (
  echo ERROR: mysql was not found.
  echo.
  echo Check if this file exists:
  echo C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe
  echo.
  echo If it exists, add that bin folder to PATH or edit MYSQL_EXE in this file.
  goto fail
)

if not exist "%SQL_FILE%" (
  echo ERROR: SQL backup file was not found:
  echo %SQL_FILE%
  echo Copy cpelab_db.sql into the database-backup folder first.
  goto fail
)

echo Using mysql: %MYSQL_EXE%
echo Using SQL file: %SQL_FILE%
echo.

"%MYSQL_EXE%" -u %DB_USER% -p%DB_PASS% -e "CREATE DATABASE IF NOT EXISTS %DB_NAME%;"
if errorlevel 1 goto fail

"%MYSQL_EXE%" -u %DB_USER% -p%DB_PASS% %DB_NAME% < "%SQL_FILE%"
if errorlevel 1 goto fail

echo Imported %SQL_FILE% into %DB_NAME%
echo.
pause
endlocal
exit /b 0

:fail
echo.
echo Database import failed. Read the error above.
pause
endlocal
exit /b 1
