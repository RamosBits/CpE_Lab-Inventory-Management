#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

DB_NAME="${DB_NAME:-cpelab_db}"
DB_USER="${DB_USER:-root}"
DB_PASS="${DB_PASS:-root}"
OUT_DIR="database-backup"

mkdir -p "$OUT_DIR"
mysqldump -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" > "$OUT_DIR/${DB_NAME}.sql"

echo "Exported database to $OUT_DIR/${DB_NAME}.sql"
